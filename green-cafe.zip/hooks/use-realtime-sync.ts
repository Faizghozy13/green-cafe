'use client';

import { useEffect, useRef } from 'react';
import { getBrowserSupabase } from '@/lib/supabase';

interface UseRealtimeSyncOptions {
  channels: Array<'orders' | 'reservations' | 'menu'>;
  onUpdate: () => void;
}

export function useRealtimeSync({ channels, onUpdate }: UseRealtimeSyncOptions) {
  const onUpdateRef = useRef(onUpdate);
  useEffect(() => {
    onUpdateRef.current = onUpdate;
  }, [onUpdate]);
  const channelKey = channels.join(',');

  useEffect(() => {
    const activeChannels = channelKey.split(',').filter(Boolean);
    if (activeChannels.length === 0) return;

    // 1. Node.js Server-Sent Events (SSE) stream for immediate local/server push
    const eventSource = new EventSource('/api/events');

    const handleSse = () => {
      onUpdateRef.current();
    };

    if (activeChannels.includes('orders')) {
      eventSource.addEventListener('orders_updated', handleSse);
    }
    if (activeChannels.includes('reservations')) {
      eventSource.addEventListener('reservations_updated', handleSse);
    }
    if (activeChannels.includes('menu')) {
      eventSource.addEventListener('menu_updated', handleSse);
    }

    // 2. Supabase Realtime Postgres Changes when public env vars are configured
    const supabase = getBrowserSupabase();
    let supabaseChannel: ReturnType<NonNullable<typeof supabase>['channel']> | null =
      null;

    if (supabase) {
      const ch = supabase.channel(`green-cafe-${channelKey}`);
      if (activeChannels.includes('orders')) {
        ch.on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'orders' },
          () => onUpdateRef.current()
        );
      }
      if (activeChannels.includes('reservations')) {
        ch.on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'reservations' },
          () => onUpdateRef.current()
        );
      }
      if (activeChannels.includes('menu')) {
        ch.on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'menu_items' },
          () => onUpdateRef.current()
        );
      }
      supabaseChannel = ch.subscribe();
    }

    return () => {
      eventSource.close();
      if (supabase && supabaseChannel) {
        supabase.removeChannel(supabaseChannel);
      }
    };
  }, [channelKey]);
}
