# Green Cafe — Sistem Pemesanan Kopi & Reservasi Real-Time

Aplikasi web pemesanan kopi, reservasi meja Dine-In, pelacakan pesanan langsung, dan dashboard operasional Barista & Admin berbasis **Next.js (Node.js)** + **Supabase Real-Time**.

## Mode Jalankan Saat Hosting

Aplikasi ini langsung siap di-hosting (Vercel, Railway, Render, Cloud Run, atau VPS Node.js):

- **Tanpa konfigurasi tambahan (Mode Real-Time Bawaan)**: Semua halaman, katalog 65 menu, checkout QRIS/Kasir, pelacakan pesanan, reservasi, dan dashboard barista langsung aktif.
- **Dengan Supabase (Direkomendasikan untuk produksi / multi-instance)**: Data pesanan, menu, dan reservasi tersimpan permanen di PostgreSQL dan tersinkron otomatis lintas perangkat via Supabase Realtime.

## Langkah Menghubungkan ke Supabase (3 Menit)

1. Buat project baru di [Supabase](https://supabase.com).
2. Buka **SQL Editor**, salin isi file `supabase/schema.sql`, lalu klik **Run**.
3. Tambahkan environment variables berikut di platform hosting Anda (lihat `.env.example`):
   - `SUPABASE_URL` — Project URL Supabase (server-side)
   - `SUPABASE_SERVICE_ROLE_KEY` — Service Role Key Supabase (**rahasia server, jangan gunakan prefix `NEXT_PUBLIC_`**)
   - `NEXT_PUBLIC_SUPABASE_URL` — Project URL Supabase (client real-time)
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY` — Anon Public Key Supabase (client real-time)

## Perintah Build & Jalankan

```bash
npm install
npm run build
npm start
```

Cek status server & mode database melalui endpoint `/api/health`.
