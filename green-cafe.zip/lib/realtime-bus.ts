import { EventEmitter } from 'node:events';

export type RealtimeEventType =
  | 'orders_updated'
  | 'reservations_updated'
  | 'menu_updated';

export interface RealtimeMessage {
  type: RealtimeEventType;
  id?: string;
  timestamp: string;
}

declare global {
  var __greenCafeRealtimeBus: EventEmitter | undefined;
}

function getBus(): EventEmitter {
  if (!globalThis.__greenCafeRealtimeBus) {
    const emitter = new EventEmitter();
    emitter.setMaxListeners(200);
    globalThis.__greenCafeRealtimeBus = emitter;
  }
  return globalThis.__greenCafeRealtimeBus;
}

export function publishRealtimeEvent(
  type: RealtimeEventType,
  id?: string
): void {
  const bus = getBus();
  const message: RealtimeMessage = {
    type,
    id,
    timestamp: new Date().toISOString(),
  };
  bus.emit('change', message);
}

export function subscribeRealtimeEvents(
  listener: (msg: RealtimeMessage) => void
): () => void {
  const bus = getBus();
  bus.on('change', listener);
  return () => {
    bus.off('change', listener);
  };
}
