import { createClient, type SupabaseClient } from '@supabase/supabase-js';

let cachedServerClient: SupabaseClient | null | undefined;
let cachedBrowserClient: SupabaseClient | null | undefined;

function isValidHttpUrl(value: string | undefined): value is string {
  if (!value) return false;
  const trimmed = value.trim();
  return trimmed.startsWith('https://') || trimmed.startsWith('http://');
}

export function isSupabaseServerConfigured(): boolean {
  const url = process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key =
    process.env.SUPABASE_SERVICE_ROLE_KEY ||
    process.env.SUPABASE_ANON_KEY ||
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  return Boolean(isValidHttpUrl(url) && key?.trim());
}

export function isSupabaseRealtimeConfigured(): boolean {
  return Boolean(
    isValidHttpUrl(process.env.NEXT_PUBLIC_SUPABASE_URL) &&
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY?.trim()
  );
}

export function getServerSupabase(): SupabaseClient | null {
  if (cachedServerClient !== undefined) {
    return cachedServerClient;
  }

  const url = process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key =
    process.env.SUPABASE_SERVICE_ROLE_KEY ||
    process.env.SUPABASE_ANON_KEY ||
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!isValidHttpUrl(url) || !key?.trim()) {
    cachedServerClient = null;
    return null;
  }

  cachedServerClient = createClient(url.trim(), key.trim(), {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  return cachedServerClient;
}

export function getBrowserSupabase(): SupabaseClient | null {
  if (typeof window === 'undefined') return null;
  if (cachedBrowserClient !== undefined) {
    return cachedBrowserClient;
  }

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!isValidHttpUrl(url) || !key?.trim()) {
    cachedBrowserClient = null;
    return null;
  }

  cachedBrowserClient = createClient(url.trim(), key.trim(), {
    realtime: {
      params: { eventsPerSecond: 10 },
    },
  });
  return cachedBrowserClient;
}
