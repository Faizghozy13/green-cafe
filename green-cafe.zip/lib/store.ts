import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { INITIAL_MENU_ITEMS } from './menu-data';
import {
  calculateOrderTotals,
  calculateSachetAdjustedPrice,
  canTransitionOrderStatus,
  generateInvoiceCode,
  getInitialOrderState,
} from './order-logic';
import { publishRealtimeEvent } from './realtime-bus';
import { getServerSupabase, isSupabaseServerConfigured } from './supabase';
import type {
  MenuCategory,
  MenuItem,
  Order,
  OrderItem,
  OrderStatus,
  PaymentMethod,
  Reservation,
  ReservationStatus,
  ServiceType,
} from './types';

interface LocalStoreState {
  menuItems: MenuItem[];
  orders: Order[];
  reservations: Reservation[];
  invoiceSequence: number;
  reservationSequence: number;
}

const STORE_FILE = path.join('/tmp', 'green-cafe-store.json');

declare global {
  var __greenCafeLocalStore: LocalStoreState | undefined;
}

function createSeedState(): LocalStoreState {
  const now = Date.now();
  const iso = (minutesAgo: number) =>
    new Date(now - minutesAgo * 60_000).toISOString();
  const today = new Date().toISOString().slice(0, 10);

  const seedOrders: Order[] = [
    {
      id: 'ord-091',
      invoiceNumber: '#INV-2026-091',
      customerName: 'Budi Santoso',
      customerPhone: '081288990011',
      serviceType: 'take_away',
      tableNumber: null,
      paymentMethod: 'cash',
      paymentStatus: 'unpaid',
      status: 'pending_payment',
      promoCode: null,
      subtotal: 48000,
      discountAmount: 0,
      taxAmount: 4800,
      packagingFee: 0,
      totalAmount: 52800,
      trxReference: null,
      estimatedMinutes: 15,
      createdAt: iso(6),
      updatedAt: iso(6),
      items: [
        {
          id: 'item-091-1',
          menuItemId: 'americano',
          name: 'Americano',
          unitPrice: 18000,
          quantity: 2,
          variantLabel: 'Ice · Normal Sweet',
          notes: 'Gula dipisah jika memungkinkan',
          lineTotal: 36000,
        },
        {
          id: 'item-091-2',
          menuItemId: 'pancong-choco-crunchy',
          name: 'Pancong Choco Crunchy',
          unitPrice: 12000,
          quantity: 1,
          variantLabel: 'Warm Classic',
          notes: '',
          lineTotal: 12000,
        },
      ],
    },
    {
      id: 'ord-089',
      invoiceNumber: '#INV-2026-089',
      customerName: 'Siti Aminah',
      customerPhone: '081344556677',
      serviceType: 'dine_in',
      tableNumber: 'Meja 04',
      paymentMethod: 'qris',
      paymentStatus: 'paid',
      status: 'preparing',
      promoCode: null,
      subtotal: 76000,
      discountAmount: 0,
      taxAmount: 7600,
      packagingFee: 0,
      totalAmount: 83600,
      trxReference: 'TRX-88291039',
      estimatedMinutes: 12,
      createdAt: iso(14),
      updatedAt: iso(12),
      items: [
        {
          id: 'item-089-1',
          menuItemId: 'coffee-aren-latte',
          name: 'Coffee Aren Latte',
          unitPrice: 27000,
          quantity: 1,
          variantLabel: 'Less Sugar (70%) · Es Normal',
          notes: 'Jangan terlalu manis',
          lineTotal: 27000,
        },
        {
          id: 'item-089-2',
          menuItemId: 'matcha-oreo',
          name: 'Matcha Oreo',
          unitPrice: 24000,
          quantity: 1,
          variantLabel: 'Normal Sweet · Extra Ice',
          notes: 'Sedotan ramah lingkungan ya',
          lineTotal: 24000,
        },
        {
          id: 'item-089-3',
          menuItemId: 'mix-platter',
          name: 'Mix Platter',
          unitPrice: 25000,
          quantity: 1,
          variantLabel: 'Warm Sharing Board',
          notes: 'Saus sambal & mayo dipisah',
          lineTotal: 25000,
        },
      ],
    },
    {
      id: 'ord-087',
      invoiceNumber: '#INV-2026-087',
      customerName: 'Raka Pratama',
      customerPhone: '081900112233',
      serviceType: 'take_away',
      tableNumber: null,
      paymentMethod: 'qris',
      paymentStatus: 'paid',
      status: 'ready',
      promoCode: null,
      subtotal: 47000,
      discountAmount: 0,
      taxAmount: 4700,
      packagingFee: 0,
      totalAmount: 51700,
      trxReference: 'TRX-88290877',
      estimatedMinutes: 5,
      createdAt: iso(25),
      updatedAt: iso(4),
      items: [
        {
          id: 'item-087-1',
          menuItemId: 'green-coffee',
          name: 'Green Coffee',
          unitPrice: 27000,
          quantity: 1,
          variantLabel: 'Regular · Less Ice',
          notes: '',
          lineTotal: 27000,
        },
        {
          id: 'item-087-2',
          menuItemId: 'dimsum-mentai',
          name: 'Dimsum Mentai',
          unitPrice: 20000,
          quantity: 1,
          variantLabel: 'Toasted Warm',
          notes: '',
          lineTotal: 20000,
        },
      ],
    },
    {
      id: 'ord-074',
      invoiceNumber: '#INV-2026-074',
      customerName: 'Nadia Kusuma',
      customerPhone: '081522334455',
      serviceType: 'take_away',
      tableNumber: null,
      paymentMethod: 'qris',
      paymentStatus: 'paid',
      status: 'completed',
      promoCode: null,
      subtotal: 47000,
      discountAmount: 0,
      taxAmount: 4700,
      packagingFee: 0,
      totalAmount: 51700,
      trxReference: 'TRX-88289901',
      estimatedMinutes: 0,
      createdAt: iso(180),
      updatedAt: iso(160),
      items: [
        {
          id: 'item-074-1',
          menuItemId: 'v60',
          name: 'V60',
          unitPrice: 20000,
          quantity: 1,
          variantLabel: 'Hot · Gayo Washed',
          notes: '',
          lineTotal: 20000,
        },
        {
          id: 'item-074-2',
          menuItemId: 'bento-set',
          name: 'Bento Set',
          unitPrice: 27000,
          quantity: 1,
          variantLabel: 'Chicken Katsu',
          notes: '',
          lineTotal: 27000,
        },
      ],
    },
    {
      id: 'ord-061',
      invoiceNumber: '#INV-2026-061',
      customerName: 'Siti Aminah',
      customerPhone: '081344556677',
      serviceType: 'dine_in',
      tableNumber: 'Meja 02',
      paymentMethod: 'card',
      paymentStatus: 'paid',
      status: 'completed',
      promoCode: null,
      subtotal: 43000,
      discountAmount: 0,
      taxAmount: 4300,
      packagingFee: 0,
      totalAmount: 47300,
      trxReference: 'TRX-88284120',
      estimatedMinutes: 0,
      createdAt: iso(320),
      updatedAt: iso(300),
      items: [
        {
          id: 'item-061-1',
          menuItemId: 'matcha',
          name: 'Matcha',
          unitPrice: 21000,
          quantity: 1,
          variantLabel: 'Ice · Normal Sweet',
          notes: '',
          lineTotal: 21000,
        },
        {
          id: 'item-061-2',
          menuItemId: 'cappuccino',
          name: 'Cappuccino',
          unitPrice: 22000,
          quantity: 1,
          variantLabel: 'Hot',
          notes: '',
          lineTotal: 22000,
        },
      ],
    },
  ];

  const seedReservations: Reservation[] = [
    {
      id: 'res-01',
      reservationCode: 'RSV-2026-014',
      customerName: 'Siti Aminah',
      customerPhone: '081344556677',
      reservationDate: today,
      reservationTime: '14:30',
      guestCount: 2,
      tableNumber: 'Meja 04',
      area: 'Indoor Botanical',
      notes: 'Dekat jendela taman',
      status: 'seated',
      createdAt: iso(90),
      updatedAt: iso(15),
    },
    {
      id: 'res-02',
      reservationCode: 'RSV-2026-015',
      customerName: 'Dimas Wijaya',
      customerPhone: '081766554433',
      reservationDate: today,
      reservationTime: '18:30',
      guestCount: 4,
      tableNumber: 'Meja 06',
      area: 'Semi-Outdoor Garden',
      notes: 'Meeting santai sore',
      status: 'confirmed',
      createdAt: iso(45),
      updatedAt: iso(45),
    },
    {
      id: 'res-03',
      reservationCode: 'RSV-2026-016',
      customerName: 'Clara Lestari',
      customerPhone: '082199887766',
      reservationDate: today,
      reservationTime: '19:30',
      guestCount: 2,
      tableNumber: 'Meja 02',
      area: 'Meja Barista',
      notes: 'Suka lihat proses V60',
      status: 'confirmed',
      createdAt: iso(20),
      updatedAt: iso(20),
    },
  ];

  return {
    menuItems: INITIAL_MENU_ITEMS.map((m) => ({ ...m })),
    orders: seedOrders,
    reservations: seedReservations,
    invoiceSequence: 92,
    reservationSequence: 17,
  };
}

function loadLocalStore(): LocalStoreState {
  if (globalThis.__greenCafeLocalStore) {
    return globalThis.__greenCafeLocalStore;
  }

  try {
    if (fs.existsSync(STORE_FILE)) {
      const raw = fs.readFileSync(STORE_FILE, 'utf8');
      const parsed = JSON.parse(raw) as LocalStoreState;
      if (parsed && Array.isArray(parsed.orders) && Array.isArray(parsed.menuItems)) {
        globalThis.__greenCafeLocalStore = parsed;
        return parsed;
      }
    }
  } catch {
    // fallback to seed state
  }

  const seeded = createSeedState();
  globalThis.__greenCafeLocalStore = seeded;
  saveLocalStore(seeded);
  return seeded;
}

function saveLocalStore(state: LocalStoreState): void {
  globalThis.__greenCafeLocalStore = state;
  try {
    fs.writeFileSync(STORE_FILE, JSON.stringify(state, null, 2), 'utf8');
  } catch {
    // ignore read-only fs errors
  }
}

function mapSupabaseMenuRow(row: Record<string, unknown>): MenuItem {
  return {
    id: String(row.id),
    name: String(row.name),
    category: row.category as MenuCategory,
    subcategory: String(row.subcategory),
    price: Number(row.price),
    description: String(row.description ?? ''),
    imageUrl: row.image_url ? String(row.image_url) : null,
    badge: row.badge ? String(row.badge) : null,
    isAddon: Boolean(row.is_addon),
    supportsSachetOptions: Boolean(row.supports_sachet_options),
    isAvailable: Boolean(row.is_available),
  };
}

function mapSupabaseOrderRow(
  row: Record<string, unknown>,
  itemsRows: Array<Record<string, unknown>>
): Order {
  return {
    id: String(row.id),
    invoiceNumber: String(row.invoice_number),
    customerName: String(row.customer_name),
    customerPhone: row.customer_phone ? String(row.customer_phone) : undefined,
    serviceType: row.service_type as ServiceType,
    tableNumber: row.table_number ? String(row.table_number) : null,
    paymentMethod: row.payment_method as PaymentMethod,
    paymentStatus: row.payment_status as Order['paymentStatus'],
    status: row.status as OrderStatus,
    promoCode: row.promo_code ? String(row.promo_code) : null,
    subtotal: Number(row.subtotal),
    discountAmount: Number(row.discount_amount ?? 0),
    taxAmount: Number(row.tax_amount ?? 0),
    packagingFee: Number(row.packaging_fee ?? 0),
    totalAmount: Number(row.total_amount),
    trxReference: row.trx_reference ? String(row.trx_reference) : null,
    estimatedMinutes: Number(row.estimated_minutes ?? 12),
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
    items: itemsRows.map((item) => ({
      id: String(item.id),
      menuItemId: String(item.menu_item_id),
      name: String(item.name),
      unitPrice: Number(item.unit_price),
      quantity: Number(item.quantity),
      variantLabel: String(item.variant_label ?? ''),
      notes: String(item.notes ?? ''),
      lineTotal: Number(item.line_total),
    })),
  };
}

function mapSupabaseReservationRow(row: Record<string, unknown>): Reservation {
  return {
    id: String(row.id),
    reservationCode: String(row.reservation_code),
    customerName: String(row.customer_name),
    customerPhone: String(row.customer_phone),
    reservationDate: String(row.reservation_date),
    reservationTime: String(row.reservation_time),
    guestCount: Number(row.guest_count),
    tableNumber: String(row.table_number),
    area: String(row.area ?? 'Indoor Botanical'),
    notes: row.notes ? String(row.notes) : '',
    status: row.status as ReservationStatus,
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
  };
}

// ==================== MENU OPERATIONS ====================

export async function listMenuItems(): Promise<MenuItem[]> {
  const supabase = getServerSupabase();
  if (supabase) {
    const { data, error } = await supabase
      .from('menu_items')
      .select('*')
      .order('created_at', { ascending: true });

    if (!error && data) {
      if (data.length === 0) {
        const seedRows = INITIAL_MENU_ITEMS.map((m) => ({
          id: m.id,
          name: m.name,
          category: m.category,
          subcategory: m.subcategory,
          price: m.price,
          description: m.description,
          image_url: m.imageUrl ?? null,
          badge: m.badge ?? null,
          is_addon: Boolean(m.isAddon),
          supports_sachet_options: Boolean(m.supportsSachetOptions),
          is_available: m.isAvailable,
        }));
        await supabase.from('menu_items').upsert(seedRows);
        return INITIAL_MENU_ITEMS;
      }
      return data.map((r) => mapSupabaseMenuRow(r as Record<string, unknown>));
    }
  }

  return loadLocalStore().menuItems;
}

export async function createMenuItem(input: {
  name: string;
  category: MenuCategory;
  subcategory: string;
  price: number;
  description: string;
  badge?: string | null;
}): Promise<MenuItem> {
  const cleanName = input.name.trim();
  if (!cleanName) throw new Error('Nama menu wajib diisi.');
  if (!Number.isFinite(input.price) || input.price < 1000) {
    throw new Error('Harga menu minimal Rp 1.000.');
  }

  const slug = cleanName
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '');
  const id = `${slug}-${Date.now().toString(36)}`;

  const newItem: MenuItem = {
    id,
    name: cleanName,
    category: input.category,
    subcategory: input.subcategory.trim() || 'Signature',
    price: Math.round(input.price),
    description: input.description.trim() || 'Racikan spesial Green Cafe',
    badge: input.badge?.trim() || null,
    isAvailable: true,
  };

  const supabase = getServerSupabase();
  if (supabase) {
    const { data, error } = await supabase
      .from('menu_items')
      .insert({
        id: newItem.id,
        name: newItem.name,
        category: newItem.category,
        subcategory: newItem.subcategory,
        price: newItem.price,
        description: newItem.description,
        badge: newItem.badge ?? null,
        is_available: true,
      })
      .select()
      .single();

    if (!error && data) {
      publishRealtimeEvent('menu_updated', newItem.id);
      return mapSupabaseMenuRow(data as Record<string, unknown>);
    }
  }

  const store = loadLocalStore();
  store.menuItems.push(newItem);
  saveLocalStore(store);
  publishRealtimeEvent('menu_updated', newItem.id);
  return newItem;
}

export async function updateMenuItem(
  id: string,
  patch: { isAvailable?: boolean; price?: number; name?: string; description?: string }
): Promise<MenuItem> {
  const supabase = getServerSupabase();
  if (supabase) {
    const updates: Record<string, unknown> = {};
    if (typeof patch.isAvailable === 'boolean') updates.is_available = patch.isAvailable;
    if (typeof patch.price === 'number' && patch.price >= 1000) {
      updates.price = Math.round(patch.price);
    }
    if (typeof patch.name === 'string' && patch.name.trim()) {
      updates.name = patch.name.trim();
    }
    if (typeof patch.description === 'string') {
      updates.description = patch.description.trim();
    }

    const { data, error } = await supabase
      .from('menu_items')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (!error && data) {
      publishRealtimeEvent('menu_updated', id);
      return mapSupabaseMenuRow(data as Record<string, unknown>);
    }
  }

  const store = loadLocalStore();
  const idx = store.menuItems.findIndex((m) => m.id === id);
  if (idx === -1) throw new Error('Menu tidak ditemukan.');

  const current = store.menuItems[idx];
  const updated: MenuItem = {
    ...current,
    isAvailable:
      typeof patch.isAvailable === 'boolean'
        ? patch.isAvailable
        : current.isAvailable,
    price:
      typeof patch.price === 'number' && patch.price >= 1000
        ? Math.round(patch.price)
        : current.price,
    name:
      typeof patch.name === 'string' && patch.name.trim()
        ? patch.name.trim()
        : current.name,
    description:
      typeof patch.description === 'string'
        ? patch.description.trim()
        : current.description,
  };
  store.menuItems[idx] = updated;
  saveLocalStore(store);
  publishRealtimeEvent('menu_updated', id);
  return updated;
}

// ==================== ORDER OPERATIONS ====================

export async function listOrders(): Promise<Order[]> {
  const supabase = getServerSupabase();
  if (supabase) {
    const { data: orderRows, error } = await supabase
      .from('orders')
      .select('*, order_items(*)')
      .order('created_at', { ascending: false })
      .limit(100);

    if (!error && orderRows) {
      return orderRows.map((row) => {
        const typedRow = row as Record<string, unknown>;
        const items = Array.isArray(typedRow.order_items)
          ? (typedRow.order_items as Array<Record<string, unknown>>)
          : [];
        return mapSupabaseOrderRow(typedRow, items);
      });
    }
  }

  const store = loadLocalStore();
  return [...store.orders].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
}

export async function getOrderByIdOrInvoice(idOrInvoice: string): Promise<Order | null> {
  const normalized = decodeURIComponent(idOrInvoice).trim();
  const supabase = getServerSupabase();

  if (supabase) {
    const isUuid =
      /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(
        normalized
      );
    const query = supabase.from('orders').select('*, order_items(*)');
    const { data, error } = isUuid
      ? await query.eq('id', normalized).maybeSingle()
      : await query.eq('invoice_number', normalized).maybeSingle();

    if (!error && data) {
      const typedRow = data as Record<string, unknown>;
      const items = Array.isArray(typedRow.order_items)
        ? (typedRow.order_items as Array<Record<string, unknown>>)
        : [];
      return mapSupabaseOrderRow(typedRow, items);
    }
  }

  const store = loadLocalStore();
  return (
    store.orders.find(
      (o) =>
        o.id === normalized ||
        o.invoiceNumber.toLowerCase() === normalized.toLowerCase()
    ) ?? null
  );
}

export interface CreateOrderInput {
  customerName: string;
  customerPhone?: string;
  serviceType: ServiceType;
  tableNumber?: string | null;
  paymentMethod: PaymentMethod;
  promoCode?: string | null;
  items: Array<{
    menuItemId: string;
    quantity: number;
    variantLabel?: string;
    notes?: string;
    temperature?: 'ice' | 'hot';
    extraBrew?: boolean;
  }>;
}

export async function createOrder(input: CreateOrderInput): Promise<Order> {
  const customerName = input.customerName.trim();
  if (!customerName) {
    throw new Error('Nama pemesan wajib diisi.');
  }
  if (!Array.isArray(input.items) || input.items.length === 0) {
    throw new Error('Keranjang pesanan masih kosong.');
  }
  if (input.serviceType === 'dine_in' && !input.tableNumber?.trim()) {
    throw new Error('Nomor meja wajib dipilih untuk layanan Dine-In.');
  }

  const menuItems = await listMenuItems();
  const menuMap = new Map(menuItems.map((m) => [m.id, m]));

  // Server-authoritative item lookup & price calculation
  const resolvedItems: OrderItem[] = input.items.map((reqItem) => {
    const menu = menuMap.get(reqItem.menuItemId);
    if (!menu) {
      throw new Error(`Menu dengan ID ${reqItem.menuItemId} tidak ditemukan.`);
    }
    if (!menu.isAvailable) {
      throw new Error(`Menu "${menu.name}" sedang habis.`);
    }
    const qty = Math.max(1, Math.min(99, Math.round(Number(reqItem.quantity) || 1)));
    const unitPrice = menu.supportsSachetOptions
      ? calculateSachetAdjustedPrice(menu.price, {
          temperature: reqItem.temperature,
          extraBrew: reqItem.extraBrew,
        })
      : menu.price;

    return {
      id: crypto.randomUUID(),
      menuItemId: menu.id,
      name: menu.name,
      unitPrice,
      quantity: qty,
      variantLabel: (reqItem.variantLabel ?? 'Standar').trim().slice(0, 120),
      notes: (reqItem.notes ?? '').trim().slice(0, 200),
      lineTotal: unitPrice * qty,
    };
  });

  const totals = calculateOrderTotals(resolvedItems, input.promoCode);
  const initialState = getInitialOrderState(input.paymentMethod);
  const now = new Date().toISOString();
  const trxReference =
    initialState.paymentStatus === 'paid'
      ? `TRX-${Math.floor(10000000 + Math.random() * 89999999)}`
      : null;

  const supabase = getServerSupabase();
  if (supabase) {
    const { count } = await supabase
      .from('orders')
      .select('*', { count: 'exact', head: true });
    const baseSeq = 100 + (count ?? 0) + 1;
    const orderId = crypto.randomUUID();
    const year = new Date().getFullYear();

    let insertedOrder: Record<string, unknown> | null = null;
    let lastErrorMessage = 'Gagal menyimpan pesanan ke Supabase.';

    for (let attempt = 0; attempt < 3; attempt++) {
      const invoiceNumber =
        attempt === 0
          ? generateInvoiceCode(baseSeq)
          : `#INV-${year}-${String(baseSeq + attempt).padStart(3, '0')}-${crypto
              .randomBytes(2)
              .toString('hex')
              .toUpperCase()}`;

      const { data, error: orderError } = await supabase
        .from('orders')
        .insert({
          id: orderId,
          invoice_number: invoiceNumber,
          customer_name: customerName,
          customer_phone: input.customerPhone?.trim() || null,
          service_type: input.serviceType,
          table_number:
            input.serviceType === 'dine_in' ? input.tableNumber?.trim() || null : null,
          payment_method: input.paymentMethod,
          payment_status: initialState.paymentStatus,
          status: initialState.status,
          promo_code: totals.promo.valid ? totals.promo.code : null,
          subtotal: totals.subtotal,
          discount_amount: totals.discountAmount,
          tax_amount: totals.taxAmount,
          packaging_fee: totals.packagingFee,
          total_amount: totals.totalAmount,
          trx_reference: trxReference,
          estimated_minutes: 12,
        })
        .select()
        .single();

      if (!orderError && data) {
        insertedOrder = data as Record<string, unknown>;
        break;
      }
      lastErrorMessage = orderError?.message || lastErrorMessage;
      if (orderError?.code !== '23505') break;
    }

    if (!insertedOrder) {
      throw new Error(lastErrorMessage);
    }

    const itemPayload = resolvedItems.map((item) => ({
      id: item.id,
      order_id: orderId,
      menu_item_id: item.menuItemId,
      name: item.name,
      unit_price: item.unitPrice,
      quantity: item.quantity,
      variant_label: item.variantLabel,
      notes: item.notes,
      line_total: item.lineTotal,
    }));

    const { error: itemsError } = await supabase
      .from('order_items')
      .insert(itemPayload);

    if (itemsError) {
      throw new Error(itemsError.message);
    }

    publishRealtimeEvent('orders_updated', orderId);
    return mapSupabaseOrderRow(
      insertedOrder as Record<string, unknown>,
      itemPayload as unknown as Array<Record<string, unknown>>
    );
  }

  const store = loadLocalStore();
  const invoiceNumber = generateInvoiceCode(store.invoiceSequence);
  store.invoiceSequence += 1;

  const newOrder: Order = {
    id: `ord-${crypto.randomUUID().slice(0, 8)}`,
    invoiceNumber,
    customerName,
    customerPhone: input.customerPhone?.trim() || undefined,
    serviceType: input.serviceType,
    tableNumber:
      input.serviceType === 'dine_in' ? input.tableNumber?.trim() || null : null,
    paymentMethod: input.paymentMethod,
    paymentStatus: initialState.paymentStatus,
    status: initialState.status,
    promoCode: totals.promo.valid ? totals.promo.code : null,
    subtotal: totals.subtotal,
    discountAmount: totals.discountAmount,
    taxAmount: totals.taxAmount,
    packagingFee: totals.packagingFee,
    totalAmount: totals.totalAmount,
    trxReference,
    estimatedMinutes: 12,
    items: resolvedItems,
    createdAt: now,
    updatedAt: now,
  };

  store.orders.unshift(newOrder);
  saveLocalStore(store);
  publishRealtimeEvent('orders_updated', newOrder.id);
  return newOrder;
}

export async function updateOrderStatus(
  id: string,
  action: 'confirm_payment' | 'verify_qris' | 'mark_ready' | 'complete' | 'cancel'
): Promise<Order> {
  const existing = await getOrderByIdOrInvoice(id);
  if (!existing) {
    throw new Error('Pesanan tidak ditemukan.');
  }

  let nextStatus: OrderStatus = existing.status;
  let nextPaymentStatus = existing.paymentStatus;
  let nextTrx = existing.trxReference;
  let nextEta = existing.estimatedMinutes;

  if (action === 'confirm_payment' || action === 'verify_qris') {
    if (!canTransitionOrderStatus(existing.status, 'preparing')) {
      if (existing.status === 'preparing' && existing.paymentStatus === 'paid') {
        return existing;
      }
      throw new Error('Status pesanan tidak dapat dikonfirmasi pembayarannya.');
    }
    nextStatus = 'preparing';
    nextPaymentStatus = 'paid';
    nextTrx = nextTrx || `TRX-${Math.floor(10000000 + Math.random() * 89999999)}`;
    nextEta = 12;
  } else if (action === 'mark_ready') {
    if (!canTransitionOrderStatus(existing.status, 'ready')) {
      throw new Error('Pesanan belum dapat ditandai siap diambil.');
    }
    nextStatus = 'ready';
    nextEta = 0;
  } else if (action === 'complete') {
    if (!canTransitionOrderStatus(existing.status, 'completed')) {
      throw new Error('Pesanan belum siap untuk diselesaikan.');
    }
    nextStatus = 'completed';
    nextPaymentStatus = 'paid';
    nextEta = 0;
  } else if (action === 'cancel') {
    if (!canTransitionOrderStatus(existing.status, 'cancelled')) {
      throw new Error('Pesanan yang sudah selesai atau dibatalkan tidak dapat diubah.');
    }
    nextStatus = 'cancelled';
    nextEta = 0;
  }

  const supabase = getServerSupabase();
  if (supabase) {
    const { data, error } = await supabase
      .from('orders')
      .update({
        status: nextStatus,
        payment_status: nextPaymentStatus,
        trx_reference: nextTrx,
        estimated_minutes: nextEta,
      })
      .eq('id', existing.id)
      .select('*, order_items(*)')
      .single();

    if (!error && data) {
      publishRealtimeEvent('orders_updated', existing.id);
      const typedRow = data as Record<string, unknown>;
      const items = Array.isArray(typedRow.order_items)
        ? (typedRow.order_items as Array<Record<string, unknown>>)
        : [];
      return mapSupabaseOrderRow(typedRow, items);
    }
  }

  const store = loadLocalStore();
  const idx = store.orders.findIndex((o) => o.id === existing.id);
  if (idx === -1) throw new Error('Pesanan tidak ditemukan.');

  const updated: Order = {
    ...store.orders[idx],
    status: nextStatus,
    paymentStatus: nextPaymentStatus,
    trxReference: nextTrx,
    estimatedMinutes: nextEta,
    updatedAt: new Date().toISOString(),
  };
  store.orders[idx] = updated;
  saveLocalStore(store);
  publishRealtimeEvent('orders_updated', updated.id);
  return updated;
}

// ==================== RESERVATION OPERATIONS ====================

export async function listReservations(): Promise<Reservation[]> {
  const supabase = getServerSupabase();
  if (supabase) {
    const { data, error } = await supabase
      .from('reservations')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(100);

    if (!error && data) {
      return data.map((r) =>
        mapSupabaseReservationRow(r as Record<string, unknown>)
      );
    }
  }

  const store = loadLocalStore();
  return [...store.reservations].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
}

export async function createReservation(input: {
  customerName: string;
  customerPhone: string;
  reservationDate: string;
  reservationTime: string;
  guestCount: number;
  tableNumber: string;
  area?: string;
  notes?: string;
}): Promise<Reservation> {
  const customerName = input.customerName.trim();
  const customerPhone = input.customerPhone.trim();
  const tableNumber = input.tableNumber.trim();
  if (!customerName) throw new Error('Nama pemesan reservasi wajib diisi.');
  if (!customerPhone) throw new Error('Nomor WhatsApp / HP wajib diisi.');
  if (!input.reservationDate || !input.reservationTime) {
    throw new Error('Tanggal dan jam kedatangan wajib diisi.');
  }
  if (!tableNumber) throw new Error('Silakan pilih meja terlebih dahulu.');

  const guestCount = Math.max(1, Math.min(20, Math.round(Number(input.guestCount) || 2)));
  const now = new Date().toISOString();

  const supabase = getServerSupabase();
  if (supabase) {
    const { count } = await supabase
      .from('reservations')
      .select('*', { count: 'exact', head: true });
    const baseSeq = 20 + (count ?? 0) + 1;
    const id = crypto.randomUUID();
    const year = new Date().getFullYear();

    for (let attempt = 0; attempt < 3; attempt++) {
      const code =
        attempt === 0
          ? `RSV-${year}-${String(baseSeq).padStart(3, '0')}`
          : `RSV-${year}-${String(baseSeq).padStart(3, '0')}-${crypto
              .randomBytes(2)
              .toString('hex')
              .toUpperCase()}`;

      const { data, error } = await supabase
        .from('reservations')
        .insert({
          id,
          reservation_code: code,
          customer_name: customerName,
          customer_phone: customerPhone,
          reservation_date: input.reservationDate,
          reservation_time: input.reservationTime,
          guest_count: guestCount,
          table_number: tableNumber,
          area: input.area?.trim() || 'Indoor Botanical',
          notes: input.notes?.trim() || null,
          status: 'confirmed',
        })
        .select()
        .single();

      if (!error && data) {
        publishRealtimeEvent('reservations_updated', id);
        return mapSupabaseReservationRow(data as Record<string, unknown>);
      }
      if (error?.code !== '23505') break;
    }
  }

  const store = loadLocalStore();
  const code = `RSV-2026-${String(store.reservationSequence).padStart(3, '0')}`;
  store.reservationSequence += 1;

  const newReservation: Reservation = {
    id: `res-${crypto.randomUUID().slice(0, 8)}`,
    reservationCode: code,
    customerName,
    customerPhone,
    reservationDate: input.reservationDate,
    reservationTime: input.reservationTime,
    guestCount,
    tableNumber,
    area: input.area?.trim() || 'Indoor Botanical',
    notes: input.notes?.trim() || '',
    status: 'confirmed',
    createdAt: now,
    updatedAt: now,
  };

  store.reservations.unshift(newReservation);
  saveLocalStore(store);
  publishRealtimeEvent('reservations_updated', newReservation.id);
  return newReservation;
}

export async function updateReservationStatus(
  id: string,
  status: ReservationStatus
): Promise<Reservation> {
  const supabase = getServerSupabase();
  if (supabase) {
    const { data, error } = await supabase
      .from('reservations')
      .update({ status })
      .eq('id', id)
      .select()
      .single();

    if (!error && data) {
      publishRealtimeEvent('reservations_updated', id);
      return mapSupabaseReservationRow(data as Record<string, unknown>);
    }
  }

  const store = loadLocalStore();
  const idx = store.reservations.findIndex((r) => r.id === id);
  if (idx === -1) throw new Error('Reservasi tidak ditemukan.');

  const updated: Reservation = {
    ...store.reservations[idx],
    status,
    updatedAt: new Date().toISOString(),
  };
  store.reservations[idx] = updated;
  saveLocalStore(store);
  publishRealtimeEvent('reservations_updated', updated.id);
  return updated;
}

export function getBackendMode(): 'supabase' | 'local-realtime' {
  return isSupabaseServerConfigured() ? 'supabase' : 'local-realtime';
}
