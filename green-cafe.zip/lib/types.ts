export type MenuCategory = 'kopi' | 'non-kopi' | 'makanan';

export interface MenuItem {
  id: string;
  name: string;
  category: MenuCategory;
  subcategory: string;
  price: number;
  description: string;
  imageUrl?: string | null;
  badge?: string | null;
  isAddon?: boolean;
  supportsSachetOptions?: boolean;
  isAvailable: boolean;
}

export interface CartItem {
  cartKey: string;
  menuItemId: string;
  name: string;
  unitPrice: number;
  basePrice: number;
  quantity: number;
  variantLabel: string;
  notes: string;
  imageUrl?: string | null;
  category: MenuCategory;
}

export type ServiceType = 'take_away' | 'dine_in';

export type PaymentMethod = 'qris' | 'cash' | 'card';

export type PaymentStatus = 'unpaid' | 'paid' | 'refunded';

export type OrderStatus =
  | 'pending_payment'
  | 'preparing'
  | 'ready'
  | 'completed'
  | 'cancelled';

export interface OrderItem {
  id: string;
  menuItemId: string;
  name: string;
  unitPrice: number;
  quantity: number;
  variantLabel: string;
  notes: string;
  lineTotal: number;
}

export interface Order {
  id: string;
  invoiceNumber: string;
  customerName: string;
  customerPhone?: string;
  serviceType: ServiceType;
  tableNumber?: string | null;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  status: OrderStatus;
  promoCode?: string | null;
  subtotal: number;
  discountAmount: number;
  taxAmount: number;
  packagingFee: number;
  totalAmount: number;
  trxReference?: string | null;
  estimatedMinutes: number;
  items: OrderItem[];
  createdAt: string;
  updatedAt: string;
}

export type ReservationStatus = 'confirmed' | 'seated' | 'completed' | 'cancelled';

export interface Reservation {
  id: string;
  reservationCode: string;
  customerName: string;
  customerPhone: string;
  reservationDate: string;
  reservationTime: string;
  guestCount: number;
  tableNumber: string;
  area: string;
  notes?: string;
  status: ReservationStatus;
  createdAt: string;
  updatedAt: string;
}

export interface DashboardMetrics {
  activeOrdersCount: number;
  awaitingCashierCount: number;
  preparingCount: number;
  readyCount: number;
  todayReservationsCount: number;
  paidRevenue: number;
  categoryRevenue: Record<MenuCategory, number>;
  topItems: Array<{ name: string; quantity: number; revenue: number }>;
}
