import type {
  DashboardMetrics,
  MenuCategory,
  MenuItem,
  Order,
  OrderStatus,
  PaymentMethod,
  Reservation,
} from './types';

export interface PromoEvaluation {
  valid: boolean;
  code: string | null;
  discountAmount: number;
  message: string;
}

export interface OrderCalculationResult {
  subtotal: number;
  discountAmount: number;
  taxAmount: number;
  packagingFee: number;
  totalAmount: number;
  promo: PromoEvaluation;
}

export function formatRupiah(amount: number): string {
  const safe = Math.max(0, Math.round(amount));
  return 'Rp ' + safe.toLocaleString('id-ID');
}

export function evaluatePromoCode(
  rawCode: string | null | undefined,
  subtotal: number
): PromoEvaluation {
  const code = (rawCode ?? '').trim().toUpperCase();
  if (!code) {
    return { valid: false, code: null, discountAmount: 0, message: '' };
  }

  if (code === 'GREEN10') {
    const discount = Math.min(25000, Math.round(subtotal * 0.1));
    return {
      valid: true,
      code,
      discountAmount: discount,
      message: 'Diskon 10% Green Club diterapkan (maks. Rp 25.000).',
    };
  }

  if (code === 'KOPIBARU') {
    if (subtotal < 30000) {
      return {
        valid: false,
        code,
        discountAmount: 0,
        message: 'Minimal belanja Rp 30.000 untuk kode KOPIBARU.',
      };
    }
    return {
      valid: true,
      code,
      discountAmount: 5000,
      message: 'Potongan Rp 5.000 berhasil diterapkan.',
    };
  }

  return {
    valid: false,
    code,
    discountAmount: 0,
    message: 'Kode promo tidak ditemukan atau sudah kedaluwarsa.',
  };
}

export function calculateSachetAdjustedPrice(
  basePrice: number,
  options: { temperature?: 'ice' | 'hot'; extraBrew?: boolean }
): number {
  let price = basePrice;
  if (options.temperature === 'hot') {
    price = Math.max(1000, price - 1000);
  }
  if (options.extraBrew) {
    price += 2000;
  }
  return price;
}

export function calculateOrderTotals(
  items: Array<{ unitPrice: number; quantity: number }>,
  promoCode?: string | null
): OrderCalculationResult {
  const subtotal = items.reduce(
    (sum, item) => sum + Math.max(0, item.unitPrice) * Math.max(1, item.quantity),
    0
  );
  const promo = evaluatePromoCode(promoCode, subtotal);
  const discountedSubtotal = Math.max(0, subtotal - promo.discountAmount);
  const taxAmount = Math.round(discountedSubtotal * 0.1);
  const packagingFee = 0;
  const totalAmount = discountedSubtotal + taxAmount + packagingFee;

  return {
    subtotal,
    discountAmount: promo.discountAmount,
    taxAmount,
    packagingFee,
    totalAmount,
    promo,
  };
}

const VALID_TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  pending_payment: ['preparing', 'cancelled'],
  preparing: ['ready', 'cancelled'],
  ready: ['completed', 'cancelled'],
  completed: [],
  cancelled: [],
};

export function canTransitionOrderStatus(
  current: OrderStatus,
  next: OrderStatus
): boolean {
  return VALID_TRANSITIONS[current]?.includes(next) ?? false;
}

export function getInitialOrderState(paymentMethod: PaymentMethod): {
  status: OrderStatus;
  paymentStatus: 'unpaid' | 'paid';
} {
  if (paymentMethod === 'cash') {
    return { status: 'pending_payment', paymentStatus: 'unpaid' };
  }
  if (paymentMethod === 'qris') {
    return { status: 'pending_payment', paymentStatus: 'unpaid' };
  }
  // Debit / card paid at terminal / instant checkout
  return { status: 'preparing', paymentStatus: 'paid' };
}

export function getOrderStepIndex(status: OrderStatus): number {
  switch (status) {
    case 'pending_payment':
      return 1;
    case 'preparing':
      return 2;
    case 'ready':
      return 3;
    case 'completed':
      return 4;
    case 'cancelled':
      return 0;
  }
}

export function getOrderStatusHeadline(status: OrderStatus): string {
  switch (status) {
    case 'pending_payment':
      return 'Menunggu Pembayaran';
    case 'preparing':
      return 'Pesanan Sedang Dipersiapkan';
    case 'ready':
      return 'Pesanan Siap Diambil';
    case 'completed':
      return 'Pesanan Selesai';
    case 'cancelled':
      return 'Pesanan Dibatalkan';
  }
}

export function generateInvoiceCode(sequenceNumber: number): string {
  const padded = String(sequenceNumber).padStart(3, '0');
  return `#INV-2026-${padded}`;
}

export function computeDashboardMetrics(
  orders: Order[],
  reservations: Reservation[],
  menuItems: MenuItem[]
): DashboardMetrics {
  const categoryMap = new Map<string, MenuCategory>();
  for (const item of menuItems) {
    categoryMap.set(item.id, item.category);
  }

  let activeOrdersCount = 0;
  let awaitingCashierCount = 0;
  let preparingCount = 0;
  let readyCount = 0;
  let paidRevenue = 0;

  const categoryRevenue: Record<MenuCategory, number> = {
    kopi: 0,
    'non-kopi': 0,
    makanan: 0,
  };

  const itemStats = new Map<string, { name: string; quantity: number; revenue: number }>();

  for (const order of orders) {
    if (
      order.status === 'pending_payment' ||
      order.status === 'preparing' ||
      order.status === 'ready'
    ) {
      activeOrdersCount += 1;
    }
    if (order.status === 'pending_payment') {
      awaitingCashierCount += 1;
    }
    if (order.status === 'preparing') {
      preparingCount += 1;
    }
    if (order.status === 'ready') {
      readyCount += 1;
    }
    if (order.paymentStatus === 'paid' && order.status !== 'cancelled') {
      paidRevenue += order.totalAmount;
      for (const item of order.items) {
        const cat = categoryMap.get(item.menuItemId) ?? 'kopi';
        categoryRevenue[cat] += item.lineTotal;

        const existing = itemStats.get(item.name) ?? {
          name: item.name,
          quantity: 0,
          revenue: 0,
        };
        existing.quantity += item.quantity;
        existing.revenue += item.lineTotal;
        itemStats.set(item.name, existing);
      }
    }
  }

  const todayReservationsCount = reservations.filter(
    (r) => r.status !== 'cancelled'
  ).length;

  const topItems = Array.from(itemStats.values())
    .sort((a, b) => b.quantity - a.quantity || b.revenue - a.revenue)
    .slice(0, 6);

  return {
    activeOrdersCount,
    awaitingCashierCount,
    preparingCount,
    readyCount,
    todayReservationsCount,
    paidRevenue,
    categoryRevenue,
    topItems,
  };
}
