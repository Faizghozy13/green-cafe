import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateOrderTotals,
  calculateSachetAdjustedPrice,
  canTransitionOrderStatus,
  computeDashboardMetrics,
  formatRupiah,
  getOrderStepIndex,
} from './order-logic';
import { filterMenuItems, INITIAL_MENU_ITEMS } from './menu-data';
import type { Order, Reservation } from './types';

test('formatRupiah formats Indonesian currency cleanly', () => {
  assert.equal(formatRupiah(27000), 'Rp 27.000');
  assert.equal(formatRupiah(0), 'Rp 0');
});

test('calculateOrderTotals computes subtotal, 10% tax, and total accurately', () => {
  const result = calculateOrderTotals([
    { unitPrice: 27000, quantity: 1 },
    { unitPrice: 24000, quantity: 1 },
    { unitPrice: 27000, quantity: 1 },
  ]);
  assert.equal(result.subtotal, 78000);
  assert.equal(result.discountAmount, 0);
  assert.equal(result.taxAmount, 7800);
  assert.equal(result.packagingFee, 0);
  assert.equal(result.totalAmount, 85800);
});

test('calculateOrderTotals applies GREEN10 and KOPIBARU promo codes correctly', () => {
  const withGreen10 = calculateOrderTotals(
    [{ unitPrice: 50000, quantity: 2 }],
    'green10'
  );
  assert.equal(withGreen10.subtotal, 100000);
  assert.equal(withGreen10.discountAmount, 10000);
  assert.equal(withGreen10.taxAmount, 9000);
  assert.equal(withGreen10.totalAmount, 99000);
  assert.equal(withGreen10.promo.valid, true);

  const belowMinKopibaru = calculateOrderTotals(
    [{ unitPrice: 20000, quantity: 1 }],
    'KOPIBARU'
  );
  assert.equal(belowMinKopibaru.promo.valid, false);
  assert.equal(belowMinKopibaru.discountAmount, 0);
});

test('calculateSachetAdjustedPrice adjusts Hot (-1K) and Extra Seduh (+2K)', () => {
  assert.equal(
    calculateSachetAdjustedPrice(10000, { temperature: 'hot', extraBrew: false }),
    9000
  );
  assert.equal(
    calculateSachetAdjustedPrice(10000, { temperature: 'ice', extraBrew: true }),
    12000
  );
  assert.equal(
    calculateSachetAdjustedPrice(10000, { temperature: 'hot', extraBrew: true }),
    11000
  );
});

test('canTransitionOrderStatus enforces valid kitchen workflow', () => {
  assert.equal(canTransitionOrderStatus('pending_payment', 'preparing'), true);
  assert.equal(canTransitionOrderStatus('preparing', 'ready'), true);
  assert.equal(canTransitionOrderStatus('ready', 'completed'), true);
  assert.equal(canTransitionOrderStatus('completed', 'preparing'), false);
  assert.equal(canTransitionOrderStatus('cancelled', 'ready'), false);
  assert.equal(getOrderStepIndex('preparing'), 2);
  assert.equal(getOrderStepIndex('ready'), 3);
});

test('filterMenuItems filters by category and search term accurately', () => {
  const kopiOnly = filterMenuItems(INITIAL_MENU_ITEMS, 'kopi', '');
  assert.ok(kopiOnly.length > 0);
  assert.ok(kopiOnly.every((item) => item.category === 'kopi'));

  const arenSearch = filterMenuItems(INITIAL_MENU_ITEMS, 'all', 'Aren');
  assert.equal(arenSearch.length, 1);
  assert.equal(arenSearch[0].name, 'Coffee Aren Latte');
});

test('computeDashboardMetrics aggregates active queue, revenue, and top items', () => {
  const orders: Order[] = [
    {
      id: 'o1',
      invoiceNumber: '#INV-2026-089',
      customerName: 'Siti Aminah',
      serviceType: 'dine_in',
      tableNumber: 'Meja 04',
      paymentMethod: 'qris',
      paymentStatus: 'paid',
      status: 'preparing',
      subtotal: 78000,
      discountAmount: 0,
      taxAmount: 7800,
      packagingFee: 0,
      totalAmount: 85800,
      estimatedMinutes: 12,
      items: [
        {
          id: 'i1',
          menuItemId: 'coffee-aren-latte',
          name: 'Coffee Aren Latte',
          unitPrice: 27000,
          quantity: 1,
          variantLabel: 'Ice',
          notes: '',
          lineTotal: 27000,
        },
        {
          id: 'i2',
          menuItemId: 'matcha-oreo',
          name: 'Matcha Oreo',
          unitPrice: 24000,
          quantity: 1,
          variantLabel: 'Ice',
          notes: '',
          lineTotal: 24000,
        },
      ],
      createdAt: '2026-11-25T07:30:00.000Z',
      updatedAt: '2026-11-25T07:30:00.000Z',
    },
    {
      id: 'o2',
      invoiceNumber: '#INV-2026-091',
      customerName: 'Budi Santoso',
      serviceType: 'take_away',
      paymentMethod: 'cash',
      paymentStatus: 'unpaid',
      status: 'pending_payment',
      subtotal: 48000,
      discountAmount: 0,
      taxAmount: 4800,
      packagingFee: 0,
      totalAmount: 52800,
      estimatedMinutes: 15,
      items: [],
      createdAt: '2026-11-25T07:42:00.000Z',
      updatedAt: '2026-11-25T07:42:00.000Z',
    },
  ];
  const reservations: Reservation[] = [
    {
      id: 'r1',
      reservationCode: 'RSV-01',
      customerName: 'Aulia',
      customerPhone: '08123456789',
      reservationDate: '2026-11-25',
      reservationTime: '18:00',
      guestCount: 4,
      tableNumber: 'Meja 02',
      area: 'Indoor Botanical',
      status: 'confirmed',
      createdAt: '2026-11-25T06:00:00.000Z',
      updatedAt: '2026-11-25T06:00:00.000Z',
    },
  ];

  const metrics = computeDashboardMetrics(orders, reservations, INITIAL_MENU_ITEMS);
  assert.equal(metrics.activeOrdersCount, 2);
  assert.equal(metrics.awaitingCashierCount, 1);
  assert.equal(metrics.preparingCount, 1);
  assert.equal(metrics.todayReservationsCount, 1);
  assert.equal(metrics.paidRevenue, 85800);
  assert.equal(metrics.categoryRevenue.kopi, 27000);
  assert.equal(metrics.categoryRevenue['non-kopi'], 24000);
});
