import { NextResponse } from 'next/server';
import { getBackendMode } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  return NextResponse.json({
    ok: true,
    backend: 'nodejs',
    databaseMode: getBackendMode(),
    timestamp: new Date().toISOString(),
  });
}
