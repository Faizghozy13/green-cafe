import { NextRequest, NextResponse } from 'next/server';
import { getOrderByIdOrInvoice, updateOrderStatus } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const ALLOWED_ACTIONS = [
  'confirm_payment',
  'verify_qris',
  'mark_ready',
  'complete',
  'cancel',
] as const;

export async function GET(
  _req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    const order = await getOrderByIdOrInvoice(id);
    if (!order) {
      return NextResponse.json(
        { error: 'Pesanan tidak ditemukan.' },
        { status: 404 }
      );
    }
    return NextResponse.json({ order });
  } catch (err) {
    const message =
      err instanceof Error ? err.message : 'Gagal memuat detail pesanan.';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function PATCH(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    const body = await req.json();
    const action = body?.action;

    if (!ALLOWED_ACTIONS.includes(action)) {
      return NextResponse.json(
        { error: 'Aksi perubahan status tidak valid.' },
        { status: 400 }
      );
    }

    const order = await updateOrderStatus(id, action);
    return NextResponse.json({ order });
  } catch (err) {
    const message =
      err instanceof Error ? err.message : 'Gagal memperbarui status pesanan.';
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
