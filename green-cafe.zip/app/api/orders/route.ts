import { NextRequest, NextResponse } from 'next/server';
import { createOrder, listOrders } from '@/lib/store';
import type { PaymentMethod, ServiceType } from '@/lib/types';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const orders = await listOrders();
    return NextResponse.json({ orders });
  } catch (err) {
    const message =
      err instanceof Error ? err.message : 'Gagal memuat daftar pesanan.';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const serviceType = body?.serviceType as ServiceType;
    const paymentMethod = body?.paymentMethod as PaymentMethod;

    if (!['take_away', 'dine_in'].includes(serviceType)) {
      return NextResponse.json(
        { error: 'Metode layanan tidak valid.' },
        { status: 400 }
      );
    }

    if (!['qris', 'cash', 'card'].includes(paymentMethod)) {
      return NextResponse.json(
        { error: 'Metode pembayaran tidak valid.' },
        { status: 400 }
      );
    }

    const order = await createOrder({
      customerName: String(body?.customerName ?? ''),
      customerPhone: body?.customerPhone ? String(body.customerPhone) : undefined,
      serviceType,
      tableNumber: body?.tableNumber ? String(body.tableNumber) : null,
      paymentMethod,
      promoCode: body?.promoCode ? String(body.promoCode) : null,
      items: Array.isArray(body?.items) ? body.items : [],
    });

    return NextResponse.json({ order }, { status: 201 });
  } catch (err) {
    const message =
      err instanceof Error ? err.message : 'Gagal membuat pesanan baru.';
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
