import { NextRequest, NextResponse } from 'next/server';
import { updateReservationStatus } from '@/lib/store';
import type { ReservationStatus } from '@/lib/types';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function PATCH(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    const body = await req.json();
    const status = body?.status as ReservationStatus;

    if (!['confirmed', 'seated', 'completed', 'cancelled'].includes(status)) {
      return NextResponse.json(
        { error: 'Status reservasi tidak valid.' },
        { status: 400 }
      );
    }

    const reservation = await updateReservationStatus(id, status);
    return NextResponse.json({ reservation });
  } catch (err) {
    const message =
      err instanceof Error ? err.message : 'Gagal memperbarui reservasi.';
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
