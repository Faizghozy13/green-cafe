import { NextRequest, NextResponse } from 'next/server';
import { createReservation, listReservations } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const reservations = await listReservations();
    return NextResponse.json({ reservations });
  } catch (err) {
    const message =
      err instanceof Error ? err.message : 'Gagal memuat daftar reservasi.';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const reservation = await createReservation({
      customerName: String(body?.customerName ?? ''),
      customerPhone: String(body?.customerPhone ?? ''),
      reservationDate: String(body?.reservationDate ?? ''),
      reservationTime: String(body?.reservationTime ?? ''),
      guestCount: Number(body?.guestCount ?? 2),
      tableNumber: String(body?.tableNumber ?? ''),
      area: body?.area ? String(body.area) : 'Indoor Botanical',
      notes: body?.notes ? String(body.notes) : '',
    });

    return NextResponse.json({ reservation }, { status: 201 });
  } catch (err) {
    const message =
      err instanceof Error ? err.message : 'Gagal membuat reservasi meja.';
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
