import { NextRequest, NextResponse } from 'next/server';
import { createMenuItem, listMenuItems } from '@/lib/store';
import type { MenuCategory } from '@/lib/types';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const items = await listMenuItems();
    return NextResponse.json({ items });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Gagal memuat daftar menu.';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const category = body?.category as MenuCategory;
    if (!['kopi', 'non-kopi', 'makanan'].includes(category)) {
      return NextResponse.json(
        { error: 'Kategori menu tidak valid.' },
        { status: 400 }
      );
    }

    const item = await createMenuItem({
      name: String(body?.name ?? ''),
      category,
      subcategory: String(body?.subcategory ?? 'Signature'),
      price: Number(body?.price ?? 0),
      description: String(body?.description ?? ''),
      badge: body?.badge ? String(body.badge) : null,
    });

    return NextResponse.json({ item }, { status: 201 });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Gagal menambahkan menu.';
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
