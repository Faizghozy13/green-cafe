import { NextRequest, NextResponse } from 'next/server';
import { updateMenuItem } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function PATCH(
  req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await context.params;
    const body = await req.json();

    const item = await updateMenuItem(id, {
      isAvailable:
        typeof body?.isAvailable === 'boolean' ? body.isAvailable : undefined,
      price: typeof body?.price === 'number' ? body.price : undefined,
      name: typeof body?.name === 'string' ? body.name : undefined,
      description:
        typeof body?.description === 'string' ? body.description : undefined,
    });

    return NextResponse.json({ item });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Gagal memperbarui menu.';
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
