import React, { Suspense } from 'react';
import { WelcomeView } from '@/components/WelcomeView';

export default function HomePage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-background flex items-center justify-center text-primary font-serif text-xl">
          Green Cafe
        </div>
      }
    >
      <WelcomeView />
    </Suspense>
  );
}
