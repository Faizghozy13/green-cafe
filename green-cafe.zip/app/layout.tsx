import type { Metadata } from 'next';
import {
  JetBrains_Mono,
  Playfair_Display,
  Plus_Jakarta_Sans,
} from 'next/font/google';
import { CartProvider } from '@/components/CartContext';
import './globals.css';

const playfair = Playfair_Display({
  subsets: ['latin'],
  weight: ['500', '600', '700'],
  variable: '--font-playfair',
});

const jakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-jakarta',
});

const jetbrains = JetBrains_Mono({
  subsets: ['latin'],
  weight: ['400', '600'],
  variable: '--font-jetbrains',
});

export const metadata: Metadata = {
  title: 'Green Cafe — Sistem Pemesanan Kopi & Reservasi Real-Time',
  description:
    'Sistem pemesanan kopi, reservasi meja dine-in, dan dashboard operasional barista real-time berbasis Node.js & Supabase.',
  openGraph: {
    title: 'Green Cafe — Sistem Pemesanan Kopi & Reservasi Real-Time',
    description:
      'Nikmati pengalaman memesan kopi organik Take Away dan reservasi Dine-In dengan pelacakan pesanan secara real-time.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Green Cafe — Sistem Pemesanan Kopi & Reservasi Real-Time',
    description:
      'Sistem pemesanan kopi, reservasi meja dine-in, dan dashboard operasional barista real-time.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="id"
      className={`${playfair.variable} ${jakarta.variable} ${jetbrains.variable}`}
    >
      <body
        suppressHydrationWarning
        className="bg-surface text-on-surface antialiased selection:bg-secondary-container selection:text-on-secondary-container"
      >
        <CartProvider>{children}</CartProvider>
      </body>
    </html>
  );
}
