import React from 'react';
import { OrderTrackingView } from '@/components/OrderTrackingView';
import { listOrders } from '@/lib/store';

export const dynamic = 'force-dynamic';

export default async function PesananDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const initialOrders = await listOrders();
  return <OrderTrackingView orderId={id} initialOrders={initialOrders} />;
}
