import React from 'react';
import { OrderTrackingView } from '@/components/OrderTrackingView';
import { listOrders } from '@/lib/store';

export const dynamic = 'force-dynamic';

export default async function PesananPage() {
  const initialOrders = await listOrders();
  return <OrderTrackingView initialOrders={initialOrders} />;
}
