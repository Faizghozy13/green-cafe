import React from 'react';
import { DashboardView } from '@/components/DashboardView';

export const dynamic = 'force-dynamic';

export default function DashboardPage() {
  return <DashboardView />;
}
