import React from 'react';
import { ReservationView } from '@/components/ReservationView';

export default function ReservasiPage() {
  return <ReservationView />;
}
