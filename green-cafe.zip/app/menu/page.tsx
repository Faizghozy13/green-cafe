import React from 'react';
import { MenuView } from '@/components/MenuView';
import { listMenuItems } from '@/lib/store';

export const dynamic = 'force-dynamic';

export default async function MenuPage() {
  const initialMenu = await listMenuItems();
  return <MenuView initialMenu={initialMenu} />;
}
