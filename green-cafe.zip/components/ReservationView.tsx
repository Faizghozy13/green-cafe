'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  ArrowRight,
  Calendar,
  CheckCircle2,
  Clock,
  Coffee,
  MapPin,
  Users,
} from 'lucide-react';
import type { Reservation } from '@/lib/types';
import { useCart } from './CartContext';
import { SiteHeader } from './SiteHeader';

const TABLES = [
  { number: 'Meja 01', capacity: 2, area: 'Indoor Botanical' },
  { number: 'Meja 02', capacity: 2, area: 'Meja Barista' },
  { number: 'Meja 03', capacity: 4, area: 'Indoor Botanical' },
  { number: 'Meja 04', capacity: 4, area: 'Indoor Botanical' },
  { number: 'Meja 05', capacity: 6, area: 'Semi-Outdoor Garden' },
  { number: 'Meja 06', capacity: 4, area: 'Semi-Outdoor Garden' },
  { number: 'Meja 07', capacity: 2, area: 'Meja Barista' },
  { number: 'Meja 08', capacity: 6, area: 'Semi-Outdoor Garden' },
];

export function ReservationView() {
  const router = useRouter();
  const { setServiceMode, showToast } = useCart();

  const todayStr = new Date().toISOString().slice(0, 10);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [reservationDate, setReservationDate] = useState(todayStr);
  const [reservationTime, setReservationTime] = useState('16:00');
  const [guestCount, setGuestCount] = useState(2);
  const [selectedTable, setSelectedTable] = useState('Meja 04');
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [confirmedReservation, setConfirmedReservation] =
    useState<Reservation | null>(null);

  const selectedTableObj =
    TABLES.find((t) => t.number === selectedTable) ?? TABLES[0];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!customerName.trim()) {
      setError('Nama lengkap wajib diisi.');
      return;
    }
    if (!customerPhone.trim()) {
      setError('Nomor WhatsApp / HP wajib diisi.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/reservations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerName,
          customerPhone,
          reservationDate,
          reservationTime,
          guestCount,
          tableNumber: selectedTable,
          area: selectedTableObj.area,
          notes,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Gagal menyimpan reservasi.');
        return;
      }

      setServiceMode('dine_in', selectedTable);
      setConfirmedReservation(data.reservation);
      showToast(`Reservasi ${selectedTable} berhasil dikonfirmasi`);
    } catch {
      setError('Terjadi gangguan koneksi. Silakan coba lagi.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-surface text-on-surface flex flex-col">
      <SiteHeader />

      <main className="flex-1 w-full pt-28 pb-20">
        <div className="max-w-5xl mx-auto px-5 md:px-8 space-y-8">
          <div className="border-b border-surface-container pb-6">
            <span className="text-xs font-semibold uppercase tracking-widest text-secondary">
              Dine-In Experience
            </span>
            <h1 className="font-serif text-3xl md:text-4xl text-primary font-semibold tracking-tight mt-1">
              Reservasi Meja Green Cafe
            </h1>
            <p className="text-sm text-on-surface-variant mt-1.5">
              Pilih meja favorit Anda dan pesan hidangan lebih awal agar langsung siap saat Anda tiba.
            </p>
          </div>

          {confirmedReservation ? (
            <div className="bg-surface-container-lowest rounded-3xl p-8 border border-surface-container shadow-sm max-w-2xl mx-auto text-center space-y-6">
              <div className="w-14 h-14 rounded-full bg-primary-fixed text-primary flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <div>
                <span className="text-xs font-semibold uppercase tracking-wider text-secondary">
                  Reservasi Terkonfirmasi
                </span>
                <h2 className="font-serif text-2xl text-primary font-semibold mt-1">
                  {confirmedReservation.tableNumber} · {confirmedReservation.area}
                </h2>
                <p className="font-mono text-sm text-on-surface-variant mt-1">
                  Kode: {confirmedReservation.reservationCode}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 rounded-2xl bg-surface-container-low text-left text-sm">
                <div>
                  <span className="text-xs text-outline block">Pemesan</span>
                  <span className="font-semibold text-primary">
                    {confirmedReservation.customerName}
                  </span>
                </div>
                <div>
                  <span className="text-xs text-outline block">Jadwal</span>
                  <span className="font-semibold text-primary tabular-nums">
                    {confirmedReservation.reservationDate} ·{' '}
                    {confirmedReservation.reservationTime} WIB
                  </span>
                </div>
                <div>
                  <span className="text-xs text-outline block">Tamu</span>
                  <span className="font-semibold text-primary">
                    {confirmedReservation.guestCount} Orang
                  </span>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setServiceMode('dine_in', confirmedReservation.tableNumber);
                    router.push('/menu');
                  }}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-full bg-primary text-on-primary text-sm font-semibold hover:bg-primary-container transition-colors"
                >
                  <Coffee className="w-4 h-4" />
                  <span>Pesan Menu untuk Meja Ini</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <Link
                  href="/"
                  className="w-full sm:w-auto px-6 py-3.5 rounded-full bg-surface-container text-primary text-sm font-semibold hover:bg-surface-container-high transition-colors"
                >
                  Kembali ke Beranda
                </Link>
              </div>
            </div>
          ) : (
            <form
              onSubmit={handleSubmit}
              className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start"
            >
              {/* Left: Table Picker */}
              <div className="lg:col-span-7 bg-surface-container-lowest rounded-3xl p-6 sm:p-7 border border-surface-container space-y-5">
                <div className="flex items-center justify-between">
                  <h2 className="font-serif text-xl text-primary font-semibold">
                    Pilih Meja &amp; Area
                  </h2>
                  <span className="text-xs text-on-surface-variant">
                    {selectedTable} · {selectedTableObj.area}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {TABLES.map((table) => {
                    const active = selectedTable === table.number;
                    return (
                      <button
                        key={table.number}
                        type="button"
                        onClick={() => setSelectedTable(table.number)}
                        className={`p-4 rounded-2xl border text-left transition-colors duration-150 ${
                          active
                            ? 'bg-primary-container text-on-primary border-primary-container shadow-sm'
                            : 'bg-surface-container-low text-on-surface border-surface-container hover:border-outline-variant'
                        }`}
                      >
                        <span className="font-serif text-base font-semibold block">
                          {table.number}
                        </span>
                        <span
                          className={`text-[11px] block mt-1 ${
                            active ? 'text-inverse-primary' : 'text-outline'
                          }`}
                        >
                          Kapasitas {table.capacity} Org
                        </span>
                        <span
                          className={`text-[10px] block mt-0.5 truncate ${
                            active
                              ? 'text-on-primary/85'
                              : 'text-on-surface-variant'
                          }`}
                        >
                          {table.area}
                        </span>
                      </button>
                    );
                  })}
                </div>

                <div className="p-4 rounded-2xl bg-surface-container-low flex items-start gap-3 text-xs text-on-surface-variant">
                  <MapPin className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                  <p>
                    Area <strong>Indoor Botanical</strong> ber-AC dengan stop kontak di setiap sudut; <strong>Semi-Outdoor Garden</strong> dikelilingi tanaman hijau teduh; <strong>Meja Barista</strong> dekat mesin espresso &amp; slow bar.
                  </p>
                </div>
              </div>

              {/* Right: Guest Details Form */}
              <div className="lg:col-span-5 bg-surface-container-lowest rounded-3xl p-6 sm:p-7 border border-surface-container space-y-4">
                <h2 className="font-serif text-xl text-primary font-semibold">
                  Detail Tamu
                </h2>

                {error && (
                  <div
                    role="alert"
                    className="p-3 rounded-xl bg-error-container text-on-error-container text-xs font-medium"
                  >
                    {error}
                  </div>
                )}

                <div>
                  <label
                    htmlFor="res-name"
                    className="text-xs font-semibold text-primary block mb-1.5"
                  >
                    Nama Pemesan
                  </label>
                  <input
                    id="res-name"
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="Masukkan nama Anda"
                    className="w-full px-4 py-2.5 rounded-xl bg-surface-container-low text-sm text-on-surface placeholder:text-outline focus:outline-none focus:ring-2 focus:ring-primary/20"
                  />
                </div>

                <div>
                  <label
                    htmlFor="res-phone"
                    className="text-xs font-semibold text-primary block mb-1.5"
                  >
                    Nomor WhatsApp / HP
                  </label>
                  <input
                    id="res-phone"
                    type="tel"
                    required
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="0812xxxxxxxx"
                    className="w-full px-4 py-2.5 rounded-xl bg-surface-container-low text-sm text-on-surface placeholder:text-outline focus:outline-none focus:ring-2 focus:ring-primary/20"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label
                      htmlFor="res-date"
                      className="text-xs font-semibold text-primary flex items-center gap-1 mb-1.5"
                    >
                      <Calendar className="w-3.5 h-3.5" />
                      <span>Tanggal</span>
                    </label>
                    <input
                      id="res-date"
                      type="date"
                      required
                      value={reservationDate}
                      onChange={(e) => setReservationDate(e.target.value)}
                      className="w-full px-3 py-2.5 rounded-xl bg-surface-container-low text-xs text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="res-time"
                      className="text-xs font-semibold text-primary flex items-center gap-1 mb-1.5"
                    >
                      <Clock className="w-3.5 h-3.5" />
                      <span>Jam</span>
                    </label>
                    <select
                      id="res-time"
                      value={reservationTime}
                      onChange={(e) => setReservationTime(e.target.value)}
                      className="w-full px-3 py-2.5 rounded-xl bg-surface-container-low text-xs text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
                    >
                      {[
                        '09:00',
                        '10:30',
                        '12:00',
                        '14:00',
                        '16:00',
                        '18:00',
                        '19:30',
                        '20:30',
                      ].map((t) => (
                        <option key={t} value={t}>
                          {t} WIB
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="res-guests"
                    className="text-xs font-semibold text-primary flex items-center gap-1 mb-1.5"
                  >
                    <Users className="w-3.5 h-3.5" />
                    <span>Jumlah Tamu</span>
                  </label>
                  <select
                    id="res-guests"
                    value={guestCount}
                    onChange={(e) => setGuestCount(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-surface-container-low text-sm text-on-surface focus:outline-none focus:ring-2 focus:ring-primary/20"
                  >
                    {[1, 2, 3, 4, 5, 6, 8].map((n) => (
                      <option key={n} value={n}>
                        {n} Orang
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="res-notes"
                    className="text-xs font-semibold text-primary block mb-1.5"
                  >
                    Catatan Tambahan (Opsional)
                  </label>
                  <input
                    id="res-notes"
                    type="text"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Contoh: Butuh colokan, acara ulang tahun..."
                    className="w-full px-4 py-2.5 rounded-xl bg-surface-container-low text-xs text-on-surface placeholder:text-outline focus:outline-none focus:ring-2 focus:ring-primary/20"
                  />
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-3.5 rounded-full bg-primary text-on-primary text-sm font-semibold hover:bg-primary-container transition-colors disabled:opacity-60 mt-2"
                >
                  {submitting ? 'Memproses Reservasi...' : 'Konfirmasi Reservasi Meja'}
                </button>
              </div>
            </form>
          )}
        </div>
      </main>
    </div>
  );
}
