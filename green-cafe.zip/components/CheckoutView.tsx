'use client';

import React, { useEffect, useMemo, useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  ArrowRight,
  CheckCircle2,
  ChevronRight,
  Coffee,
  CreditCard,
  FileText,
  Lock,
  Minus,
  Plus,
  QrCode,
  RefreshCw,
  ShieldCheck,
  ShoppingBag,
  Sprout,
  Store,
  Tag,
  Timer,
  Trash2,
  X,
} from 'lucide-react';
import { calculateOrderTotals, formatRupiah } from '@/lib/order-logic';
import type { Order, PaymentMethod } from '@/lib/types';
import { useCart } from './CartContext';
import { QrisCodeMatrix } from './QrisCodeMatrix';
import { SiteHeader } from './SiteHeader';

export function CheckoutView() {
  const router = useRouter();
  const {
    items,
    totalCount,
    serviceType,
    tableNumber,
    setServiceMode,
    setLastOrderId,
    updateQuantity,
    updateNotes,
    removeItem,
    clearCart,
    showToast,
  } = useCart();

  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('qris');
  const [promoInput, setPromoInput] = useState('');
  const [appliedPromo, setAppliedPromo] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState('');

  // QRIS modal state
  const [pendingQrisOrder, setPendingQrisOrder] = useState<Order | null>(null);
  const [verifyingQris, setVerifyingQris] = useState(false);
  const [countdownSec, setCountdownSec] = useState(14 * 60 + 59);

  useEffect(() => {
    if (!pendingQrisOrder) return;
    const timer = setInterval(() => {
      setCountdownSec((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, [pendingQrisOrder]);

  const formattedCountdown = useMemo(() => {
    const mins = Math.floor(countdownSec / 60);
    const secs = countdownSec % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }, [countdownSec]);

  const calculation = useMemo(
    () => calculateOrderTotals(items, appliedPromo),
    [items, appliedPromo]
  );

  const handleApplyPromo = () => {
    const trimmed = promoInput.trim();
    if (!trimmed) {
      setAppliedPromo(null);
      return;
    }
    const preview = calculateOrderTotals(items, trimmed);
    setAppliedPromo(trimmed);
    if (!preview.promo.valid) {
      showToast(preview.promo.message);
    } else {
      showToast(preview.promo.message);
    }
  };

  const handlePlaceOrder = async () => {
    setFormError('');
    if (items.length === 0) {
      setFormError('Keranjang masih kosong. Silakan pilih menu terlebih dahulu.');
      return;
    }
    if (!customerName.trim()) {
      setFormError('Nama pemesan wajib diisi sebelum melanjutkan pembayaran.');
      return;
    }
    if (serviceType === 'dine_in' && !tableNumber.trim()) {
      setFormError('Silakan pilih nomor meja untuk layanan Dine-In.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerName: customerName.trim(),
          customerPhone: customerPhone.trim() || undefined,
          serviceType,
          tableNumber: serviceType === 'dine_in' ? tableNumber : null,
          paymentMethod,
          promoCode: calculation.promo.valid ? calculation.promo.code : null,
          items: items.map((i) => ({
            menuItemId: i.menuItemId,
            quantity: i.quantity,
            variantLabel: i.variantLabel,
            notes: i.notes,
            temperature: i.variantLabel.toLowerCase().includes('hot')
              ? 'hot'
              : 'ice',
            extraBrew: i.variantLabel.toLowerCase().includes('extra seduh'),
          })),
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setFormError(data.error || 'Gagal memproses pesanan.');
        return;
      }

      const createdOrder: Order = data.order;
      setLastOrderId(createdOrder.id);

      if (paymentMethod === 'qris') {
        setCountdownSec(14 * 60 + 59);
        setPendingQrisOrder(createdOrder);
      } else {
        clearCart();
        showToast(`Pesanan ${createdOrder.invoiceNumber} berhasil dibuat`);
        router.push(`/pesanan/${createdOrder.id}`);
      }
    } catch {
      setFormError('Gagal terhubung ke server. Periksa koneksi Anda.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleVerifyQrisPayment = async () => {
    if (!pendingQrisOrder) return;
    setVerifyingQris(true);
    try {
      const res = await fetch(`/api/orders/${pendingQrisOrder.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'verify_qris' }),
      });
      if (!res.ok) {
        showToast('Gagal memverifikasi pembayaran QRIS.');
        return;
      }
      clearCart();
      const targetId = pendingQrisOrder.id;
      setPendingQrisOrder(null);
      showToast('Pembayaran QRIS terverifikasi! Pesanan diteruskan ke barista.');
      router.push(`/pesanan/${targetId}`);
    } catch {
      showToast('Terjadi kesalahan saat verifikasi pembayaran.');
    } finally {
      setVerifyingQris(false);
    }
  };

  const handleCancelQris = async () => {
    if (!pendingQrisOrder) return;
    try {
      await fetch(`/api/orders/${pendingQrisOrder.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'cancel' }),
      });
    } catch {
      // ignore
    } finally {
      setPendingQrisOrder(null);
    }
  };

  return (
    <div className="min-h-screen bg-surface text-on-surface flex flex-col">
      <SiteHeader />

      <main className="flex-1 w-full pt-28 pb-20">
        <div className="max-w-[1200px] mx-auto px-5 md:px-8 lg:px-12">
          {/* Breadcrumbs & Page Title */}
          <div className="pb-8 border-b border-surface-container">
            <nav
              aria-label="Breadcrumb"
              className="flex items-center gap-1.5 text-xs text-on-surface-variant"
            >
              <Link href="/" className="hover:text-primary transition-colors">
                Beranda
              </Link>
              <ChevronRight className="w-3.5 h-3.5 text-outline-variant" />
              <Link href="/menu" className="hover:text-primary transition-colors">
                Daftar Menu
              </Link>
              <ChevronRight className="w-3.5 h-3.5 text-outline-variant" />
              <span className="font-semibold text-primary">Pembayaran</span>
            </nav>

            <div className="mt-4 flex flex-col md:flex-row md:items-baseline justify-between gap-4">
              <div>
                <h1 className="font-serif text-3xl md:text-4xl text-primary font-semibold tracking-tight">
                  Pembayaran
                </h1>
                <p className="text-sm text-on-surface-variant mt-1.5">
                  Periksa rincian pesanan Anda dan selesaikan transaksi secara aman.
                </p>
              </div>
              <div className="flex items-center gap-4 text-xs text-on-surface-variant">
                <span className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-primary" />
                  Enkripsi Aman
                </span>
                <span aria-hidden="true">·</span>
                <span className="flex items-center gap-1.5">
                  <Sprout className="w-4 h-4 text-primary" />
                  100% Kemasan Eco-friendly
                </span>
              </div>
            </div>
          </div>

          {items.length === 0 ? (
            <div className="my-12 bg-surface-container-lowest rounded-3xl p-10 text-center border border-surface-container max-w-xl mx-auto space-y-5">
              <div className="w-14 h-14 rounded-full bg-surface-container-low text-primary flex items-center justify-center mx-auto">
                <ShoppingBag className="w-6 h-6" />
              </div>
              <div>
                <h2 className="font-serif text-2xl text-primary font-semibold">
                  Keranjang Anda Masih Kosong
                </h2>
                <p className="text-sm text-on-surface-variant mt-1.5">
                  Jelajahi racikan kopi signature, minuman segar, dan camilan hangat di Daftar Menu kami.
                </p>
              </div>
              <Link
                href="/menu"
                className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full bg-primary text-on-primary text-sm font-semibold hover:bg-primary-container transition-colors"
              >
                <span>Pilih Menu Sekarang</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start pt-8">
              {/* LEFT COLUMN: 60% (7 cols) */}
              <div className="lg:col-span-7 flex flex-col gap-7">
                {/* Customer Info */}
                <section className="bg-surface-container-lowest rounded-3xl p-6 border border-surface-container space-y-4">
                  <h2 className="font-serif text-xl text-primary font-semibold">
                    Informasi Pemesan
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label
                        htmlFor="checkout-name"
                        className="text-xs font-semibold text-primary block mb-1.5"
                      >
                        Nama Pemesan *
                      </label>
                      <input
                        id="checkout-name"
                        type="text"
                        required
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        placeholder="Contoh: Siti Aminah"
                        className="w-full px-4 py-2.5 rounded-xl bg-surface-container-low text-sm text-on-surface placeholder:text-outline focus:outline-none focus:ring-2 focus:ring-primary/20"
                      />
                    </div>
                    <div>
                      <label
                        htmlFor="checkout-phone"
                        className="text-xs font-semibold text-primary block mb-1.5"
                      >
                        No. WhatsApp (Opsional)
                      </label>
                      <input
                        id="checkout-phone"
                        type="tel"
                        value={customerPhone}
                        onChange={(e) => setCustomerPhone(e.target.value)}
                        placeholder="0812xxxxxxxx"
                        className="w-full px-4 py-2.5 rounded-xl bg-surface-container-low text-sm text-on-surface placeholder:text-outline focus:outline-none focus:ring-2 focus:ring-primary/20"
                      />
                    </div>
                  </div>
                </section>

                {/* Order Items */}
                <section className="bg-surface-container-lowest rounded-3xl p-6 border border-surface-container">
                  <div className="flex items-center justify-between pb-4 border-b border-surface-container">
                    <div className="flex items-center gap-2.5">
                      <h2 className="font-serif text-xl text-primary font-semibold">
                        Daftar Pesanan
                      </h2>
                      <span className="text-xs font-medium text-on-surface-variant tabular-nums">
                        · {totalCount} Item
                      </span>
                    </div>
                    <Link
                      href="/menu"
                      className="text-xs font-semibold text-secondary hover:text-on-secondary-container transition-colors inline-flex items-center gap-1"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Tambah Menu</span>
                    </Link>
                  </div>

                  <div className="divide-y divide-surface-container">
                    {items.map((item) => (
                      <div key={item.cartKey} className="py-5 flex items-start gap-4">
                        <div className="relative w-20 h-20 rounded-xl overflow-hidden bg-surface-container shrink-0 flex items-center justify-center">
                          {item.imageUrl ? (
                            <Image
                              src={item.imageUrl}
                              alt={item.name}
                              fill
                              sizes="80px"
                              referrerPolicy="no-referrer"
                              className="object-cover"
                            />
                          ) : (
                            <Coffee className="w-6 h-6 text-outline/70" />
                          )}
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-3">
                            <div>
                              <h3 className="font-serif text-base text-primary font-semibold">
                                {item.name}
                              </h3>
                              <p className="text-xs text-on-surface-variant mt-0.5">
                                {item.variantLabel}
                              </p>
                            </div>
                            <button
                              type="button"
                              aria-label={`Hapus ${item.name}`}
                              onClick={() => removeItem(item.cartKey)}
                              className="text-outline hover:text-error transition-colors p-1"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>

                          <div className="mt-3.5 flex items-center justify-between gap-3">
                            <div className="inline-flex items-center rounded-full border border-surface-container-highest px-2 py-0.5">
                              <button
                                type="button"
                                aria-label={`Kurangi jumlah ${item.name}`}
                                onClick={() => updateQuantity(item.cartKey, -1)}
                                className="w-6 h-6 flex items-center justify-center text-primary/80 hover:text-primary"
                              >
                                <Minus className="w-3.5 h-3.5" />
                              </button>
                              <span className="w-7 text-center text-xs font-semibold text-primary tabular-nums">
                                {item.quantity}
                              </span>
                              <button
                                type="button"
                                aria-label={`Tambah jumlah ${item.name}`}
                                onClick={() => updateQuantity(item.cartKey, 1)}
                                className="w-6 h-6 flex items-center justify-center text-primary/80 hover:text-primary"
                              >
                                <Plus className="w-3.5 h-3.5" />
                              </button>
                            </div>
                            <span className="font-semibold text-sm text-primary tabular-nums">
                              {formatRupiah(item.unitPrice * item.quantity)}
                            </span>
                          </div>

                          <div className="mt-3 flex items-center gap-1.5 text-xs text-on-surface-variant">
                            <FileText className="w-3.5 h-3.5 text-outline shrink-0" />
                            <input
                              type="text"
                              value={item.notes}
                              onChange={(e) =>
                                updateNotes(item.cartKey, e.target.value)
                              }
                              aria-label={`Catatan barista untuk ${item.name}`}
                              placeholder="Tambah catatan untuk barista..."
                              className="w-full bg-transparent text-xs text-on-surface placeholder:text-outline/70 focus:outline-none border-b border-transparent focus:border-outline-variant py-0.5"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </section>

                {/* Promo & Eco Note */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="rounded-2xl p-5 bg-surface-container-lowest border border-surface-container flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-2 text-primary font-semibold text-sm mb-1">
                        <Tag className="w-4 h-4 text-secondary" />
                        <span>Kode Promo</span>
                      </div>
                      <p className="text-xs text-on-surface-variant">
                        Coba kode <code className="font-mono font-semibold">GREEN10</code> atau{' '}
                        <code className="font-mono font-semibold">KOPIBARU</code>.
                      </p>
                    </div>
                    <div className="mt-4 flex items-center gap-2">
                      <input
                        type="text"
                        value={promoInput}
                        onChange={(e) => setPromoInput(e.target.value)}
                        aria-label="Masukkan kode promo"
                        placeholder="Ketik kode promo..."
                        className="flex-1 bg-surface-container-low px-3.5 py-2 rounded-xl text-xs text-on-surface placeholder:text-outline focus:outline-none focus:ring-1 focus:ring-primary/25"
                      />
                      <button
                        type="button"
                        onClick={handleApplyPromo}
                        className="px-4 py-2 rounded-xl bg-primary-container text-on-primary text-xs font-semibold hover:bg-primary transition-colors whitespace-nowrap"
                      >
                        Terapkan
                      </button>
                    </div>
                    {appliedPromo && (
                      <p
                        className={`text-[11px] mt-2 font-medium ${
                          calculation.promo.valid ? 'text-primary' : 'text-error'
                        }`}
                      >
                        {calculation.promo.message}
                      </p>
                    )}
                  </div>

                  <div className="rounded-2xl p-5 bg-surface-container-low border border-surface-container flex flex-col justify-between">
                    <div className="flex items-start gap-3">
                      <div className="w-9 h-9 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0">
                        <Sprout className="w-4 h-4" />
                      </div>
                      <div>
                        <h3 className="text-xs font-semibold text-primary">
                          Kemasan 100% Biodegradable
                        </h3>
                        <p className="text-xs text-on-surface-variant mt-1 leading-relaxed">
                          Kemasan ramah lingkungan dari serat bambu &amp; singkong organik tanpa biaya tambahan.
                        </p>
                      </div>
                    </div>
                    <div className="mt-3 flex items-center gap-1.5 text-primary text-[11px] font-medium">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Bebas biaya kemasan</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* RIGHT COLUMN: 40% (5 cols) Sticky Summary */}
              <div className="lg:col-span-5 lg:sticky lg:top-28 flex flex-col gap-5">
                <div className="bg-surface-container-lowest rounded-3xl p-6 lg:p-7 border border-surface-container shadow-[0_4px_24px_rgba(24,37,25,0.04)] space-y-5">
                  {/* Service Mode Selector */}
                  <div className="pb-4 border-b border-surface-container space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <Store className="w-5 h-5 text-primary" />
                        <div>
                          <span className="text-[11px] text-on-surface-variant uppercase tracking-wider block">
                            Pilihan Layanan
                          </span>
                          <span className="text-sm font-semibold text-primary">
                            {serviceType === 'dine_in'
                              ? `Dine-In · ${tableNumber}`
                              : 'Take Away (Bawa Pulang)'}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setServiceMode('take_away')}
                        className={`py-2 px-3 rounded-xl text-xs font-semibold border transition-colors ${
                          serviceType === 'take_away'
                            ? 'bg-primary-container text-on-primary border-primary-container'
                            : 'bg-surface-container-low text-on-surface-variant border-surface-container'
                        }`}
                      >
                        Take Away
                      </button>
                      <button
                        type="button"
                        onClick={() => setServiceMode('dine_in', tableNumber || 'Meja 04')}
                        className={`py-2 px-3 rounded-xl text-xs font-semibold border transition-colors ${
                          serviceType === 'dine_in'
                            ? 'bg-primary-container text-on-primary border-primary-container'
                            : 'bg-surface-container-low text-on-surface-variant border-surface-container'
                        }`}
                      >
                        Dine-In (Meja)
                      </button>
                    </div>

                    {serviceType === 'dine_in' && (
                      <div>
                        <label
                          htmlFor="checkout-table"
                          className="text-xs font-medium text-on-surface-variant block mb-1"
                        >
                          Pilih Nomor Meja
                        </label>
                        <select
                          id="checkout-table"
                          value={tableNumber}
                          onChange={(e) => setServiceMode('dine_in', e.target.value)}
                          className="w-full px-3 py-2 rounded-xl bg-surface-container-low text-xs font-semibold text-primary focus:outline-none"
                        >
                          {[
                            'Meja 01',
                            'Meja 02',
                            'Meja 03',
                            'Meja 04',
                            'Meja 05',
                            'Meja 06',
                            'Meja 07',
                            'Meja 08',
                          ].map((t) => (
                            <option key={t} value={t}>
                              {t}
                            </option>
                          ))}
                        </select>
                      </div>
                    )}
                  </div>

                  {/* Payment Methods */}
                  <div>
                    <h2 className="font-serif text-lg text-primary font-semibold mb-3">
                      Metode Pembayaran
                    </h2>
                    <div className="space-y-2.5">
                      <label
                        className={`flex items-start gap-3 p-3.5 rounded-2xl border cursor-pointer transition-colors ${
                          paymentMethod === 'qris'
                            ? 'bg-surface-container border-primary/40'
                            : 'bg-surface-container-low/60 border-transparent hover:bg-surface-container-low'
                        }`}
                      >
                        <input
                          type="radio"
                          name="payment_method"
                          value="qris"
                          checked={paymentMethod === 'qris'}
                          onChange={() => setPaymentMethod('qris')}
                          className="mt-1 accent-primary"
                        />
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-bold text-primary">
                              QRIS Instan
                            </span>
                            <QrCode className="w-4 h-4 text-primary" />
                          </div>
                          <p className="text-xs text-on-surface-variant mt-0.5">
                            BCA, GoPay, OVO, ShopeePay, Dana, m-Banking
                          </p>
                        </div>
                      </label>

                      <label
                        className={`flex items-start gap-3 p-3.5 rounded-2xl border cursor-pointer transition-colors ${
                          paymentMethod === 'cash'
                            ? 'bg-surface-container border-primary/40'
                            : 'bg-surface-container-low/60 border-transparent hover:bg-surface-container-low'
                        }`}
                      >
                        <input
                          type="radio"
                          name="payment_method"
                          value="cash"
                          checked={paymentMethod === 'cash'}
                          onChange={() => setPaymentMethod('cash')}
                          className="mt-1 accent-primary"
                        />
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-bold text-primary">
                              Bayar di Kasir
                            </span>
                            <Store className="w-4 h-4 text-outline" />
                          </div>
                          <p className="text-xs text-on-surface-variant mt-0.5">
                            Tunjukkan nomor invoice ke barista saat mengambil
                          </p>
                        </div>
                      </label>

                      <label
                        className={`flex items-start gap-3 p-3.5 rounded-2xl border cursor-pointer transition-colors ${
                          paymentMethod === 'card'
                            ? 'bg-surface-container border-primary/40'
                            : 'bg-surface-container-low/60 border-transparent hover:bg-surface-container-low'
                        }`}
                      >
                        <input
                          type="radio"
                          name="payment_method"
                          value="card"
                          checked={paymentMethod === 'card'}
                          onChange={() => setPaymentMethod('card')}
                          className="mt-1 accent-primary"
                        />
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-bold text-primary">
                              Debit / Kartu Kredit
                            </span>
                            <CreditCard className="w-4 h-4 text-outline" />
                          </div>
                          <p className="text-xs text-on-surface-variant mt-0.5">
                            Visa, Mastercard, GPN
                          </p>
                        </div>
                      </label>
                    </div>
                  </div>

                  {/* Price Breakdown */}
                  <div className="space-y-2 pt-4 border-t border-surface-container text-xs text-on-surface-variant">
                    <div className="flex justify-between items-center">
                      <span>Subtotal ({totalCount} item)</span>
                      <span className="text-on-surface font-semibold tabular-nums">
                        {formatRupiah(calculation.subtotal)}
                      </span>
                    </div>
                    {calculation.discountAmount > 0 && (
                      <div className="flex justify-between items-center text-secondary font-medium">
                        <span>Diskon Promo ({calculation.promo.code})</span>
                        <span className="tabular-nums">
                          -{formatRupiah(calculation.discountAmount)}
                        </span>
                      </div>
                    )}
                    <div className="flex justify-between items-center">
                      <span>Pajak Restoran (10%)</span>
                      <span className="text-on-surface font-semibold tabular-nums">
                        {formatRupiah(calculation.taxAmount)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Kemasan Ramah Lingkungan</span>
                      <span className="text-secondary font-semibold">Gratis</span>
                    </div>

                    <div className="pt-3 border-t border-surface-container flex justify-between items-baseline">
                      <div>
                        <span className="text-[11px] uppercase tracking-wider block text-on-surface-variant">
                          Total Tagihan
                        </span>
                        <span className="font-serif text-2xl font-bold text-primary tabular-nums">
                          {formatRupiah(calculation.totalAmount)}
                        </span>
                      </div>
                      <span className="text-[11px] text-primary font-medium">
                        Termasuk Pajak
                      </span>
                    </div>
                  </div>

                  {formError && (
                    <div
                      role="alert"
                      className="p-3 rounded-xl bg-error-container text-on-error-container text-xs font-medium"
                    >
                      {formError}
                    </div>
                  )}

                  <button
                    type="button"
                    disabled={submitting}
                    onClick={handlePlaceOrder}
                    className="w-full py-3.5 rounded-full bg-primary text-on-primary font-semibold text-sm hover:bg-primary-container transition-all flex items-center justify-center gap-2 shadow-sm disabled:opacity-60 tabular-nums"
                  >
                    <span>
                      {submitting
                        ? 'Membuat Pesanan...'
                        : `Bayar Sekarang · ${formatRupiah(calculation.totalAmount)}`}
                    </span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <p className="text-[11px] text-center text-outline flex items-center justify-center gap-1.5">
                    <Lock className="w-3.5 h-3.5" />
                    <span>Pembayaran aman &amp; tersinkron real-time</span>
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* QRIS Payment Modal */}
      {pendingQrisOrder && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-primary/45 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-labelledby="qris-modal-title"
        >
          <div className="relative w-full max-w-md bg-surface-container-lowest rounded-3xl p-6 sm:p-7 shadow-2xl flex flex-col items-center">
            <button
              type="button"
              aria-label="Tutup modal pembayaran QRIS"
              onClick={handleCancelQris}
              className="absolute top-5 right-5 w-8 h-8 rounded-full bg-surface-container flex items-center justify-center text-on-surface-variant hover:text-primary"
            >
              <X className="w-4 h-4" />
            </button>

            <span className="text-xs font-semibold text-secondary uppercase tracking-wider mb-1">
              Menunggu Pembayaran QRIS
            </span>
            <h2
              id="qris-modal-title"
              className="font-mono text-sm font-bold text-primary"
            >
              Invoice {pendingQrisOrder.invoiceNumber}
            </h2>

            <div className="my-4 py-2 px-5 rounded-full bg-surface-container-high flex items-center gap-2 text-primary text-xs font-medium">
              <Timer className="w-4 h-4 text-secondary" />
              <span>
                Selesaikan dalam{' '}
                <strong className="font-mono text-sm font-bold tabular-nums">
                  {formattedCountdown}
                </strong>
              </span>
            </div>

            <QrisCodeMatrix value={pendingQrisOrder.invoiceNumber} />

            <p className="text-xs text-on-surface-variant text-center mt-3 max-w-[260px]">
              Scan dengan BCA Mobile, GoPay, OVO, ShopeePay, atau m-Banking pilihan Anda.
            </p>

            <div className="w-full mt-4 p-3.5 bg-surface-container rounded-2xl flex items-center justify-between">
              <span className="text-xs text-on-surface-variant">
                Total Tagihan:
              </span>
              <span className="font-serif text-lg font-bold text-primary tabular-nums">
                {formatRupiah(pendingQrisOrder.totalAmount)}
              </span>
            </div>

            <div className="w-full flex flex-col gap-2 mt-4">
              <button
                type="button"
                disabled={verifyingQris}
                onClick={handleVerifyQrisPayment}
                className="w-full py-3.5 rounded-full bg-primary text-on-primary text-sm font-semibold hover:bg-primary-container transition-colors flex items-center justify-center gap-2 disabled:opacity-60"
              >
                <RefreshCw
                  className={`w-4 h-4 ${verifyingQris ? 'animate-spin' : ''}`}
                />
                <span>
                  {verifyingQris
                    ? 'Memverifikasi Pembayaran...'
                    : 'Cek Status Pembayaran'}
                </span>
              </button>
              <button
                type="button"
                onClick={handleCancelQris}
                className="w-full py-2 text-xs text-outline hover:text-error transition-colors"
              >
                Batalkan Transaksi
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
