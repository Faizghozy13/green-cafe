'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Menu, ShoppingBag, X } from 'lucide-react';
import { useCart } from './CartContext';

export function SiteHeader() {
  const pathname = usePathname();
  const { totalCount, lastOrderId } = useCart();
  const [mobileOpen, setMobileOpen] = useState(false);

  const pesananHref = lastOrderId ? `/pesanan/${lastOrderId}` : '/pesanan';

  const navLinks = [
    { href: '/menu', label: 'Menu' },
    { href: '/reservasi', label: 'Reservasi' },
    { href: pesananHref, label: 'Pesanan Saya', matchPrefix: '/pesanan' },
    { href: '/dashboard', label: 'Barista' },
  ];

  const isActive = (href: string, matchPrefix?: string) => {
    if (matchPrefix) return pathname.startsWith(matchPrefix);
    return pathname === href;
  };

  return (
    <header className="fixed top-0 left-0 right-0 w-full z-40 bg-surface/90 backdrop-blur-md border-b border-surface-container no-print">
      <div className="h-20 max-w-[1200px] mx-auto px-5 md:px-8 lg:px-12 flex items-center justify-between gap-8">
        <Link
          href="/"
          className="font-serif text-2xl text-primary tracking-tight font-semibold whitespace-nowrap shrink-0"
        >
          Green Cafe
        </Link>

        <nav className="hidden md:flex items-center gap-7" aria-label="Navigasi Utama">
          {navLinks.map((link) => {
            const active = isActive(link.href, link.matchPrefix);
            return (
              <Link
                key={link.label}
                href={link.href}
                className={`text-sm font-medium whitespace-nowrap shrink-0 transition-colors pb-1 border-b-2 ${
                  active
                    ? 'text-primary border-primary'
                    : 'text-on-surface-variant border-transparent hover:text-primary hover:border-outline-variant'
                }`}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>

        <div className="flex items-center gap-3 shrink-0">
          <Link
            href="/checkout"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary-container text-on-primary text-sm font-semibold hover:bg-primary transition-colors whitespace-nowrap shrink-0 tabular-nums"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Keranjang ({totalCount})</span>
          </Link>

          <button
            type="button"
            aria-label={mobileOpen ? 'Tutup Menu Navigasi' : 'Buka Menu Navigasi'}
            onClick={() => setMobileOpen((prev) => !prev)}
            className="md:hidden w-10 h-10 rounded-full bg-surface-container flex items-center justify-center text-primary hover:bg-surface-container-high transition-colors"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="md:hidden bg-surface-container-low border-t border-surface-container px-5 py-4 flex flex-col gap-2">
          {navLinks.map((link) => {
            const active = isActive(link.href, link.matchPrefix);
            return (
              <Link
                key={link.label}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className={`px-4 py-2.5 rounded-xl text-sm font-semibold transition-colors ${
                  active
                    ? 'bg-primary-container text-on-primary'
                    : 'text-on-surface-variant hover:bg-surface-container'
                }`}
              >
                {link.label}
              </Link>
            );
          })}
        </div>
      )}
    </header>
  );
}
