'use client';

import React, { useMemo } from 'react';
import { Sprout } from 'lucide-react';

interface QrisCodeMatrixProps {
  value: string;
  size?: 'sm' | 'md';
}

export function QrisCodeMatrix({ value, size = 'md' }: QrisCodeMatrixProps) {
  const grid = useMemo(() => {
    const N = 21;
    const cells: boolean[][] = Array.from({ length: N }, () =>
      Array(N).fill(false)
    );

    const drawFinder = (top: number, left: number) => {
      for (let r = 0; r < 7; r++) {
        for (let c = 0; c < 7; c++) {
          const isOuter = r === 0 || r === 6 || c === 0 || c === 6;
          const isInner = r >= 2 && r <= 4 && c >= 2 && c <= 4;
          cells[top + r][left + c] = isOuter || isInner;
        }
      }
    };

    drawFinder(0, 0);
    drawFinder(0, N - 7);
    drawFinder(N - 7, 0);

    let hash = 2166136261;
    for (let i = 0; i < value.length; i++) {
      hash ^= value.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }

    for (let r = 0; r < N; r++) {
      for (let c = 0; c < N; c++) {
        const inTopLeft = r < 8 && c < 8;
        const inTopRight = r < 8 && c >= N - 8;
        const inBottomLeft = r >= N - 8 && c < 8;
        const inCenterLogo = r >= 8 && r <= 12 && c >= 8 && c <= 12;
        if (inTopLeft || inTopRight || inBottomLeft || inCenterLogo) continue;

        hash ^= r * 31 + c * 17;
        hash = Math.imul(hash, 16777619);
        cells[r][c] = (hash >>> 0) % 2 === 0;
      }
    }

    return cells;
  }, [value]);

  const boxSize = size === 'sm' ? 'w-40 h-40' : 'w-48 h-48';

  return (
    <div
      className={`relative ${boxSize} bg-white p-2.5 rounded-2xl border border-surface-container shadow-sm select-none`}
      aria-label={`Kode QRIS untuk ${value}`}
    >
      <div
        className="w-full h-full grid gap-[1px]"
        style={{ gridTemplateColumns: 'repeat(21, minmax(0, 1fr))' }}
      >
        {grid.flatMap((row, r) =>
          row.map((filled, c) => (
            <div
              key={`${r}-${c}`}
              className={`rounded-[1px] ${
                filled ? 'bg-primary' : 'bg-transparent'
              }`}
            />
          ))
        )}
      </div>

      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-8 h-8 rounded-lg bg-white p-1 shadow-sm flex items-center justify-center">
          <div className="w-full h-full rounded-md bg-primary text-surface flex items-center justify-center">
            <Sprout className="w-4 h-4" />
          </div>
        </div>
      </div>
    </div>
  );
}
