'use client';

import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import type { CartItem, MenuItem, ServiceType } from '@/lib/types';

interface AddCartOptions {
  quantity?: number;
  variantLabel?: string;
  notes?: string;
  customUnitPrice?: number;
}

interface ToastMessage {
  id: string;
  text: string;
}

interface CartContextValue {
  items: CartItem[];
  totalCount: number;
  serviceType: ServiceType;
  tableNumber: string;
  lastOrderId: string | null;
  setServiceMode: (mode: ServiceType, tableNumber?: string) => void;
  setLastOrderId: (id: string | null) => void;
  addItem: (menuItem: MenuItem, options?: AddCartOptions) => void;
  updateQuantity: (cartKey: string, delta: number) => void;
  updateNotes: (cartKey: string, notes: string) => void;
  removeItem: (cartKey: string) => void;
  clearCart: () => void;
  showToast: (text: string) => void;
}

const STORAGE_KEY = 'green_cafe_cart_v1';

const CartContext = createContext<CartContextValue | null>(null);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [serviceType, setServiceType] = useState<ServiceType>('take_away');
  const [tableNumber, setTableNumber] = useState<string>('Meja 04');
  const [lastOrderId, setLastOrderIdState] = useState<string | null>(null);
  const [hydrated, setHydrated] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  useEffect(() => {
    Promise.resolve().then(() => {
      try {
        const raw = window.localStorage.getItem(STORAGE_KEY);
        if (raw) {
          const parsed = JSON.parse(raw);
          if (Array.isArray(parsed.items)) setItems(parsed.items);
          if (
            parsed.serviceType === 'dine_in' ||
            parsed.serviceType === 'take_away'
          ) {
            setServiceType(parsed.serviceType);
          }
          if (typeof parsed.tableNumber === 'string' && parsed.tableNumber) {
            setTableNumber(parsed.tableNumber);
          }
          if (typeof parsed.lastOrderId === 'string') {
            setLastOrderIdState(parsed.lastOrderId);
          }
        }
      } catch {
        // ignore storage errors
      } finally {
        setHydrated(true);
      }
    });
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    try {
      window.localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({ items, serviceType, tableNumber, lastOrderId })
      );
    } catch {
      // ignore storage errors
    }
  }, [items, serviceType, tableNumber, lastOrderId, hydrated]);

  const showToast = useCallback((text: string) => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    setToasts((prev) => [...prev.slice(-2), { id, text }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 2600);
  }, []);

  const setServiceMode = useCallback((mode: ServiceType, nextTable?: string) => {
    setServiceType(mode);
    if (nextTable !== undefined) {
      setTableNumber(nextTable);
    }
  }, []);

  const setLastOrderId = useCallback((id: string | null) => {
    setLastOrderIdState(id);
  }, []);

  const addItem = useCallback(
    (menuItem: MenuItem, options?: AddCartOptions) => {
      const variantLabel = (options?.variantLabel ?? 'Standar').trim() || 'Standar';
      const unitPrice = options?.customUnitPrice ?? menuItem.price;
      const qty = Math.max(1, options?.quantity ?? 1);
      const notes = (options?.notes ?? '').trim();
      const cartKey = `${menuItem.id}::${variantLabel}::${unitPrice}`;

      setItems((prev) => {
        const idx = prev.findIndex((i) => i.cartKey === cartKey);
        if (idx !== -1) {
          const updated = [...prev];
          updated[idx] = {
            ...updated[idx],
            quantity: updated[idx].quantity + qty,
            notes: notes || updated[idx].notes,
          };
          return updated;
        }
        return [
          ...prev,
          {
            cartKey,
            menuItemId: menuItem.id,
            name: menuItem.name,
            unitPrice,
            basePrice: menuItem.price,
            quantity: qty,
            variantLabel,
            notes,
            imageUrl: menuItem.imageUrl ?? null,
            category: menuItem.category,
          },
        ];
      });

      showToast(`${menuItem.name} ditambahkan ke keranjang`);
    },
    [showToast]
  );

  const updateQuantity = useCallback((cartKey: string, delta: number) => {
    setItems((prev) =>
      prev
        .map((item) =>
          item.cartKey === cartKey
            ? { ...item, quantity: item.quantity + delta }
            : item
        )
        .filter((item) => item.quantity > 0)
    );
  }, []);

  const updateNotes = useCallback((cartKey: string, notes: string) => {
    setItems((prev) =>
      prev.map((item) =>
        item.cartKey === cartKey ? { ...item, notes } : item
      )
    );
  }, []);

  const removeItem = useCallback((cartKey: string) => {
    setItems((prev) => prev.filter((item) => item.cartKey !== cartKey));
  }, []);

  const clearCart = useCallback(() => {
    setItems([]);
  }, []);

  const totalCount = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <CartContext.Provider
      value={{
        items,
        totalCount,
        serviceType,
        tableNumber,
        lastOrderId,
        setServiceMode,
        setLastOrderId,
        addItem,
        updateQuantity,
        updateNotes,
        removeItem,
        clearCart,
        showToast,
      }}
    >
      {children}
      {toasts.length > 0 && (
        <div
          aria-live="polite"
          className="fixed top-20 right-5 z-50 flex flex-col gap-2 pointer-events-none no-print"
        >
          {toasts.map((toast) => (
            <div
              key={toast.id}
              className="px-4 py-3 rounded-xl bg-primary text-on-primary text-sm font-medium shadow-lg flex items-center gap-2"
            >
              <span>{toast.text}</span>
            </div>
          ))}
        </div>
      )}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) {
    throw new Error('useCart must be used within CartProvider');
  }
  return ctx;
}
