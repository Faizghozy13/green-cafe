'use client';

import React, { useCallback, useEffect, useMemo, useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import {
  Check,
  Coffee,
  GlassWater,
  Plus,
  Search,
  ShoppingBag,
  Sprout,
  Utensils,
  X,
} from 'lucide-react';
import {
  filterMenuItems,
  INITIAL_MENU_ITEMS,
  MENU_SUBCATEGORY_ORDER,
} from '@/lib/menu-data';
import {
  calculateSachetAdjustedPrice,
  formatRupiah,
} from '@/lib/order-logic';
import type { MenuCategory, MenuItem } from '@/lib/types';
import { useRealtimeSync } from '@/hooks/use-realtime-sync';
import { useCart } from './CartContext';
import { SiteHeader } from './SiteHeader';

const CATEGORY_META: Record<
  MenuCategory,
  { title: string; subtitle: string; icon: React.ReactNode }
> = {
  kopi: {
    title: 'Kopi',
    subtitle: 'Pilihan Kopi & Seduhan',
    icon: <Coffee className="w-4 h-4" />,
  },
  'non-kopi': {
    title: 'Non-Kopi',
    subtitle: 'Segar & Pilihan Minuman Sehat',
    icon: <GlassWater className="w-4 h-4" />,
  },
  makanan: {
    title: 'Makanan',
    subtitle: 'Main Course, Snack & Pancong',
    icon: <Utensils className="w-4 h-4" />,
  },
};

export function MenuView({
  initialMenu = INITIAL_MENU_ITEMS,
}: {
  initialMenu?: MenuItem[];
}) {
  const { addItem, totalCount, items: cartItems, serviceType, tableNumber } = useCart();
  const [menuItems, setMenuItems] = useState<MenuItem[]>(initialMenu);
  const [activeCategory, setActiveCategory] = useState<MenuCategory | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [justAddedId, setJustAddedId] = useState<string | null>(null);

  // Customization modal state
  const [customizingItem, setCustomizingItem] = useState<MenuItem | null>(null);
  const [tempOption, setTempOption] = useState<'ice' | 'hot'>('ice');
  const [sugarOption, setSugarOption] = useState<string>('Normal Sweet');
  const [extraBrew, setExtraBrew] = useState<boolean>(false);
  const [customQty, setCustomQty] = useState<number>(1);
  const [customNotes, setCustomNotes] = useState<string>('');

  const fetchMenu = useCallback(async () => {
    try {
      const res = await fetch('/api/menu', { cache: 'no-store' });
      if (!res.ok) return;
      const data = await res.json();
      if (Array.isArray(data.items)) {
        setMenuItems(data.items);
      }
    } catch {
      // keep existing menu
    }
  }, []);

  useEffect(() => {
    const id = setTimeout(() => {
      void fetchMenu();
    }, 0);
    return () => clearTimeout(id);
  }, [fetchMenu]);

  useRealtimeSync({
    channels: ['menu'],
    onUpdate: fetchMenu,
  });

  const filteredItems = useMemo(
    () => filterMenuItems(menuItems, activeCategory, searchQuery),
    [menuItems, activeCategory, searchQuery]
  );

  const visibleCategories: MenuCategory[] =
    activeCategory === 'all'
      ? ['kopi', 'non-kopi', 'makanan']
      : [activeCategory];

  const handleQuickAdd = (item: MenuItem) => {
    if (!item.isAvailable) return;
    const defaultVariant =
      item.category === 'makanan'
        ? 'Hangat Standar'
        : item.supportsSachetOptions
        ? 'Ice · Standar'
        : 'Ice · Normal Sweet';

    addItem(item, {
      quantity: 1,
      variantLabel: defaultVariant,
    });
    setJustAddedId(item.id);
    setTimeout(() => {
      setJustAddedId((prev) => (prev === item.id ? null : prev));
    }, 800);
  };

  const openCustomizeModal = (item: MenuItem) => {
    if (!item.isAvailable) return;
    setCustomizingItem(item);
    setTempOption('ice');
    setSugarOption('Normal Sweet');
    setExtraBrew(false);
    setCustomQty(1);
    setCustomNotes('');
  };

  const handleConfirmCustomize = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customizingItem) return;

    const parts: string[] = [];
    if (customizingItem.category !== 'makanan' && !customizingItem.isAddon) {
      parts.push(tempOption === 'ice' ? 'Ice' : 'Hot');
      parts.push(sugarOption);
      if (customizingItem.supportsSachetOptions && extraBrew) {
        parts.push('Extra Seduh');
      }
    } else {
      parts.push('Standar');
    }

    const customPrice = customizingItem.supportsSachetOptions
      ? calculateSachetAdjustedPrice(customizingItem.price, {
          temperature: tempOption,
          extraBrew,
        })
      : customizingItem.price;

    addItem(customizingItem, {
      quantity: customQty,
      variantLabel: parts.join(' · '),
      notes: customNotes,
      customUnitPrice: customPrice,
    });
    setCustomizingItem(null);
  };

  const cartSubtotal = cartItems.reduce(
    (sum, item) => sum + item.unitPrice * item.quantity,
    0
  );

  return (
    <div className="min-h-screen bg-surface text-on-surface flex flex-col">
      <SiteHeader />

      <main className="flex-1 w-full pt-24 pb-28">
        <div className="max-w-[1200px] mx-auto px-5 md:px-8 lg:px-12 flex flex-col gap-8">
          {/* Hero Header */}
          <section className="flex flex-col items-center text-center gap-2 pt-2">
            <div className="inline-flex items-center gap-2 text-xs font-medium text-secondary tracking-wide">
              <Sprout className="w-4 h-4" />
              <span>
                Layanan Aktif:{' '}
                {serviceType === 'dine_in'
                  ? `Dine-In · ${tableNumber}`
                  : 'Take Away'}
              </span>
            </div>
            <h1 className="font-serif text-3xl md:text-5xl text-primary font-semibold tracking-tight text-balance">
              Daftar Menu
            </h1>
            <p className="text-sm text-on-surface-variant max-w-lg">
              Seduhan kopi organik pilihan, minuman segar botani, hingga hidangan hangat pendamping santai Anda.
            </p>
          </section>

          {/* Sticky Filter & Search Bar */}
          <section className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4 sticky top-20 z-30 bg-surface/95 backdrop-blur-md py-3 border-b border-surface-container-high/70">
            <div
              className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1 lg:pb-0"
              role="tablist"
              aria-label="Filter Kategori Menu"
            >
              {(
                [
                  { id: 'all', label: 'Semua' },
                  { id: 'kopi', label: 'Kopi' },
                  { id: 'non-kopi', label: 'Non-Kopi' },
                  { id: 'makanan', label: 'Makanan' },
                ] as const
              ).map((tab) => {
                const active = activeCategory === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    role="tab"
                    aria-selected={active}
                    onClick={() => setActiveCategory(tab.id)}
                    className={`px-5 py-2.5 rounded-full text-sm font-semibold whitespace-nowrap shrink-0 transition-all ${
                      active
                        ? 'bg-primary-container text-on-primary shadow-sm'
                        : 'bg-surface-container-low text-on-surface-variant hover:text-primary hover:bg-surface-container-high'
                    }`}
                  >
                    {tab.label}
                  </button>
                );
              })}
            </div>

            <div className="relative w-full lg:w-80">
              <Search className="w-4 h-4 text-outline absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                aria-label="Cari menu"
                placeholder="Cari menu favoritmu..."
                className="w-full pl-11 pr-9 py-2.5 rounded-full bg-surface-container-lowest text-sm text-on-surface placeholder:text-outline border border-surface-container-high focus:outline-none focus:ring-2 focus:ring-primary-container/25 transition-all"
              />
              {searchQuery && (
                <button
                  type="button"
                  aria-label="Hapus pencarian"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-outline hover:text-primary p-1"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </section>

          {/* Empty Search State */}
          {filteredItems.length === 0 && (
            <div className="py-16 text-center bg-surface-container-low rounded-3xl px-6">
              <p className="font-serif text-xl text-primary font-semibold mb-2">
                Menu tidak ditemukan
              </p>
              <p className="text-sm text-on-surface-variant mb-6">
                Coba kata kunci lain atau lihat seluruh kategori menu Green Cafe.
              </p>
              <button
                type="button"
                onClick={() => {
                  setActiveCategory('all');
                  setSearchQuery('');
                }}
                className="px-6 py-2.5 rounded-full bg-primary-container text-on-primary text-sm font-semibold hover:bg-primary transition-colors"
              >
                Tampilkan Semua Menu
              </button>
            </div>
          )}

          {/* Category Sections */}
          {visibleCategories.map((cat) => {
            const catItems = filteredItems.filter((i) => i.category === cat);
            if (catItems.length === 0) return null;

            const subcategories = Array.from(
              new Set([
                ...MENU_SUBCATEGORY_ORDER[cat],
                ...catItems.map((i) => i.subcategory),
              ])
            );

            const meta = CATEGORY_META[cat];

            return (
              <section
                key={cat}
                id={`section-${cat}`}
                className="flex flex-col gap-7 pt-2"
              >
                <div className="flex items-center justify-between pb-2.5 border-b border-surface-container-high">
                  <div className="flex items-center gap-2.5">
                    <span className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center">
                      {meta.icon}
                    </span>
                    <h2 className="font-serif text-2xl text-primary font-semibold tracking-tight">
                      {meta.title}
                    </h2>
                  </div>
                  <span className="text-xs font-medium text-outline">
                    {meta.subtitle}
                  </span>
                </div>

                {subcategories.map((sub) => {
                  const subItems = catItems.filter((i) => i.subcategory === sub);
                  if (subItems.length === 0) return null;

                  const isAddonGroup = sub.startsWith('Add-On');
                  const isSachetGroup =
                    sub === 'Kopi Sachet' || sub === 'Non Kopi Sachet';

                  return (
                    <div
                      key={sub}
                      className={
                        isAddonGroup
                          ? 'flex flex-col gap-4 bg-surface-container-low/70 p-5 rounded-2xl border border-outline-variant/40'
                          : 'flex flex-col gap-4'
                      }
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div className="flex items-center gap-2.5">
                          <h3 className="font-serif text-lg text-primary font-semibold">
                            {sub}
                          </h3>
                          {sub === 'Flavourcano' && (
                            <span className="text-xs text-outline">
                              · Espresso Infused Flavors
                            </span>
                          )}
                          {sub === 'Manual Brew' && (
                            <span className="text-xs text-outline">
                              · Artisanal Pour-Over
                            </span>
                          )}
                        </div>
                        {isSachetGroup && (
                          <span className="text-xs font-medium text-secondary">
                            Catatan: Panas / Hot -1K · Extra Seduh +2K
                          </span>
                        )}
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                        {subItems.map((item) => {
                          const isAdded = justAddedId === item.id;
                          return (
                            <article
                              key={item.id}
                              className={`group flex flex-col justify-between bg-surface-container-lowest rounded-2xl overflow-hidden border border-surface-container shadow-sm hover:shadow-md transition-all duration-200 ${
                                !item.isAvailable ? 'opacity-65' : ''
                              }`}
                            >
                              <button
                                type="button"
                                onClick={() => openCustomizeModal(item)}
                                disabled={!item.isAvailable}
                                className="text-left focus:outline-none"
                                aria-label={`Lihat detail dan kustomisasi ${item.name}`}
                              >
                                <div className="relative aspect-[4/3] w-full overflow-hidden bg-surface-container-low flex items-center justify-center">
                                  {item.imageUrl ? (
                                    <Image
                                      src={item.imageUrl}
                                      alt={item.name}
                                      fill
                                      priority={item.id === 'green-coffee'}
                                      sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
                                      referrerPolicy="no-referrer"
                                      className="object-cover transition-transform duration-500 group-hover:scale-105"
                                    />
                                  ) : (
                                    <div className="flex flex-col items-center justify-center gap-1.5 text-outline/70">
                                      <Coffee className="w-6 h-6 opacity-60" />
                                      <span className="text-[11px] font-medium tracking-wide">
                                        {item.subcategory}
                                      </span>
                                    </div>
                                  )}

                                  {item.badge && (
                                    <span className="absolute top-3 left-3 bg-secondary-container text-on-secondary-container px-2.5 py-1 rounded-full text-[11px] font-semibold shadow-sm">
                                      {item.badge}
                                    </span>
                                  )}

                                  {!item.isAvailable && (
                                    <span className="absolute inset-0 bg-surface/75 flex items-center justify-center text-xs font-bold uppercase tracking-wider text-error">
                                      Stok Habis
                                    </span>
                                  )}
                                </div>
                              </button>

                              <div className="p-4 flex flex-col flex-1 justify-between gap-4">
                                <div>
                                  <button
                                    type="button"
                                    onClick={() => openCustomizeModal(item)}
                                    disabled={!item.isAvailable}
                                    className="text-left font-serif text-lg text-primary font-semibold group-hover:text-secondary transition-colors block"
                                  >
                                    {item.name}
                                  </button>
                                  <p className="text-xs text-outline mt-1 leading-relaxed">
                                    {item.description}
                                  </p>
                                </div>

                                <div className="flex items-center justify-between pt-1 mt-auto gap-2">
                                  <div className="flex flex-col">
                                    <span className="text-[11px] text-outline">
                                      Harga
                                    </span>
                                    <span className="font-serif text-base text-primary font-bold tabular-nums">
                                      {formatRupiah(item.price)}
                                    </span>
                                  </div>

                                  <button
                                    type="button"
                                    disabled={!item.isAvailable}
                                    aria-label={`Tambah ${item.name} ke keranjang`}
                                    onClick={() => handleQuickAdd(item)}
                                    className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-semibold transition-all whitespace-nowrap shrink-0 ${
                                      !item.isAvailable
                                        ? 'bg-surface-container text-outline cursor-not-allowed'
                                        : isAdded
                                        ? 'bg-secondary text-on-secondary shadow-sm'
                                        : 'bg-primary-container text-on-primary hover:bg-primary active:scale-95 shadow-sm'
                                    }`}
                                  >
                                    {isAdded ? (
                                      <>
                                        <Check className="w-3.5 h-3.5" />
                                        <span>Ditambahkan</span>
                                      </>
                                    ) : (
                                      <>
                                        <Plus className="w-3.5 h-3.5" />
                                        <span>Tambah</span>
                                      </>
                                    )}
                                  </button>
                                </div>
                              </div>
                            </article>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </section>
            );
          })}
        </div>
      </main>

      {/* Floating Checkout Bar when cart has items */}
      {totalCount > 0 && (
        <div className="fixed bottom-4 left-4 right-4 z-30 max-w-xl mx-auto">
          <Link
            href="/checkout"
            className="w-full px-5 py-3.5 rounded-full bg-primary text-on-primary shadow-xl flex items-center justify-between gap-4 hover:bg-primary-container transition-colors"
          >
            <div className="flex items-center gap-3">
              <span className="w-8 h-8 rounded-full bg-surface/15 flex items-center justify-center">
                <ShoppingBag className="w-4 h-4" />
              </span>
              <div className="text-left">
                <span className="text-xs text-inverse-primary block">
                  {totalCount} item di keranjang
                </span>
                <span className="text-sm font-bold tabular-nums">
                  {formatRupiah(cartSubtotal)}
                </span>
              </div>
            </div>
            <span className="text-sm font-semibold whitespace-nowrap">
              Lanjut Pembayaran →
            </span>
          </Link>
        </div>
      )}

      {/* Customization Modal */}
      {customizingItem && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-primary/45 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-labelledby="custom-modal-title"
        >
          <form
            onSubmit={handleConfirmCustomize}
            className="w-full max-w-md bg-surface-container-lowest rounded-3xl p-6 shadow-2xl space-y-5 relative"
          >
            <button
              type="button"
              aria-label="Tutup modal kustomisasi"
              onClick={() => setCustomizingItem(null)}
              className="absolute top-5 right-5 w-8 h-8 rounded-full bg-surface-container flex items-center justify-center text-on-surface-variant hover:text-primary"
            >
              <X className="w-4 h-4" />
            </button>

            <div>
              <span className="text-xs font-medium text-secondary">
                {customizingItem.subcategory}
              </span>
              <h2
                id="custom-modal-title"
                className="font-serif text-2xl text-primary font-semibold mt-0.5"
              >
                {customizingItem.name}
              </h2>
              <p className="text-xs text-on-surface-variant mt-1">
                {customizingItem.description}
              </p>
            </div>

            {customizingItem.category !== 'makanan' && !customizingItem.isAddon && (
              <div className="space-y-4">
                <div>
                  <span className="text-xs font-semibold text-primary block mb-2">
                    Suhu Penyajian
                  </span>
                  <div className="grid grid-cols-2 gap-2.5">
                    <button
                      type="button"
                      onClick={() => setTempOption('ice')}
                      className={`py-2.5 px-3 rounded-xl text-xs font-semibold border transition-colors ${
                        tempOption === 'ice'
                          ? 'bg-primary-container text-on-primary border-primary-container'
                          : 'bg-surface-container-low text-on-surface border-surface-container'
                      }`}
                    >
                      Dingin / Ice
                    </button>
                    <button
                      type="button"
                      onClick={() => setTempOption('hot')}
                      className={`py-2.5 px-3 rounded-xl text-xs font-semibold border transition-colors ${
                        tempOption === 'hot'
                          ? 'bg-primary-container text-on-primary border-primary-container'
                          : 'bg-surface-container-low text-on-surface border-surface-container'
                      }`}
                    >
                      Panas / Hot{' '}
                      {customizingItem.supportsSachetOptions ? '(-Rp 1.000)' : ''}
                    </button>
                  </div>
                </div>

                <div>
                  <span className="text-xs font-semibold text-primary block mb-2">
                    Tingkat Gula
                  </span>
                  <div className="grid grid-cols-3 gap-2">
                    {['Less Sugar', 'Normal Sweet', 'No Sugar'].map((level) => (
                      <button
                        key={level}
                        type="button"
                        onClick={() => setSugarOption(level)}
                        className={`py-2 px-2 rounded-xl text-xs font-medium border transition-colors ${
                          sugarOption === level
                            ? 'bg-secondary-container text-on-secondary-container border-secondary-container font-semibold'
                            : 'bg-surface-container-low text-on-surface-variant border-surface-container'
                        }`}
                      >
                        {level}
                      </button>
                    ))}
                  </div>
                </div>

                {customizingItem.supportsSachetOptions && (
                  <label className="flex items-center justify-between p-3 rounded-xl bg-surface-container-low cursor-pointer">
                    <div>
                      <span className="text-xs font-semibold text-primary block">
                        Extra Seduh (+Rp 2.000)
                      </span>
                      <span className="text-[11px] text-on-surface-variant">
                        Takaran double sachet lebih pekat
                      </span>
                    </div>
                    <input
                      type="checkbox"
                      checked={extraBrew}
                      onChange={(e) => setExtraBrew(e.target.checked)}
                      className="w-4 h-4 accent-primary"
                    />
                  </label>
                )}
              </div>
            )}

            <div>
              <label
                htmlFor="custom-notes"
                className="text-xs font-semibold text-primary block mb-1.5"
              >
                Catatan untuk Barista (Opsional)
              </label>
              <input
                id="custom-notes"
                type="text"
                value={customNotes}
                onChange={(e) => setCustomNotes(e.target.value)}
                placeholder="Contoh: Sedotan ramah lingkungan, es dipisah..."
                className="w-full px-3.5 py-2.5 rounded-xl bg-surface-container-low text-xs text-on-surface placeholder:text-outline focus:outline-none focus:ring-2 focus:ring-primary/20"
              />
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-surface-container">
              <div className="inline-flex items-center rounded-full border border-surface-container-highest px-2 py-1">
                <button
                  type="button"
                  aria-label="Kurangi jumlah"
                  onClick={() => setCustomQty((q) => Math.max(1, q - 1))}
                  className="w-7 h-7 flex items-center justify-center text-primary font-bold"
                >
                  −
                </button>
                <span className="w-8 text-center text-sm font-bold text-primary tabular-nums">
                  {customQty}
                </span>
                <button
                  type="button"
                  aria-label="Tambah jumlah"
                  onClick={() => setCustomQty((q) => q + 1)}
                  className="w-7 h-7 flex items-center justify-center text-primary font-bold"
                >
                  +
                </button>
              </div>

              <button
                type="submit"
                className="px-6 py-3 rounded-full bg-primary text-on-primary text-sm font-semibold hover:bg-primary-container transition-colors tabular-nums"
              >
                Tambah ·{' '}
                {formatRupiah(
                  (customizingItem.supportsSachetOptions
                    ? calculateSachetAdjustedPrice(customizingItem.price, {
                        temperature: tempOption,
                        extraBrew,
                      })
                    : customizingItem.price) * customQty
                )}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
