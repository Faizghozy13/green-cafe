'use client';

import React, { useCallback, useEffect, useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import {
  ArrowLeft,
  Check,
  CheckCircle2,
  ChevronDown,
  Clock,
  Coffee,
  Download,
  ExternalLink,
  FileText,
  History,
  Hourglass,
  MessageCircle,
  QrCode,
  ReceiptText,
  Sprout,
  Store,
} from 'lucide-react';
import {
  formatRupiah,
  getOrderStatusHeadline,
  getOrderStepIndex,
} from '@/lib/order-logic';
import type { Order } from '@/lib/types';
import { useRealtimeSync } from '@/hooks/use-realtime-sync';
import { useCart } from './CartContext';
import { SiteHeader } from './SiteHeader';

interface OrderTrackingViewProps {
  orderId?: string;
  initialOrders?: Order[];
}

export function OrderTrackingView({
  orderId,
  initialOrders = [],
}: OrderTrackingViewProps) {
  const { lastOrderId, setLastOrderId } = useCart();
  const [orders, setOrders] = useState<Order[]>(initialOrders);
  const [loading, setLoading] = useState(initialOrders.length === 0);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [downloaded, setDownloaded] = useState(false);

  const fetchOrders = useCallback(async () => {
    try {
      const res = await fetch('/api/orders', { cache: 'no-store' });
      if (!res.ok) return;
      const data = await res.json();
      if (Array.isArray(data.orders)) {
        setOrders(data.orders);
      }
    } catch {
      // ignore network glitches
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const id = setTimeout(() => {
      void fetchOrders();
    }, 0);
    return () => clearTimeout(id);
  }, [fetchOrders]);

  useRealtimeSync({
    channels: ['orders'],
    onUpdate: fetchOrders,
  });

  const targetId = orderId || lastOrderId;
  const currentOrder =
    orders.find(
      (o) =>
        o.id === targetId ||
        o.invoiceNumber.toLowerCase() === (targetId ?? '').toLowerCase()
    ) ??
    orders.find((o) => o.status !== 'completed' && o.status !== 'cancelled') ??
    orders[0] ??
    null;

  useEffect(() => {
    if (!orderId && currentOrder && currentOrder.id !== lastOrderId) {
      setLastOrderId(currentOrder.id);
    }
  }, [orderId, currentOrder, lastOrderId, setLastOrderId]);

  const pastOrders = orders
    .filter((o) => o.id !== currentOrder?.id)
    .slice(0, 5);

  const stepIndex = currentOrder ? getOrderStepIndex(currentOrder.status) : 1;
  const progressPercent =
    stepIndex <= 1 ? 8 : stepIndex === 2 ? 38 : stepIndex === 3 ? 72 : 100;

  const handleDownloadReceipt = () => {
    if (!currentOrder) return;
    setDownloaded(true);
    window.print();
    setTimeout(() => setDownloaded(false), 2500);
  };

  const formattedDate = currentOrder
    ? new Date(currentOrder.createdAt).toLocaleString('id-ID', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }) + ' WIB'
    : '';

  return (
    <div className="min-h-screen bg-surface text-on-surface flex flex-col">
      <SiteHeader />

      <main className="flex-1 w-full pt-28 pb-20">
        <div className="w-full max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 space-y-7">
          {/* Top Navigation / Breadcrumbs */}
          <div className="flex items-center justify-between pt-1 no-print">
            <Link
              href="/menu"
              className="inline-flex items-center gap-2 text-xs font-semibold text-on-surface-variant hover:text-primary transition-colors group"
            >
              <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
              <span>Kembali ke Menu</span>
            </Link>
            <div className="inline-flex items-center gap-1.5 text-xs text-outline">
              <span>Pesanan Saya</span>
              <span aria-hidden="true">/</span>
              <span className="text-primary font-semibold">Pelacakan</span>
            </div>
          </div>

          {loading ? (
            <div className="rounded-3xl bg-surface-container-low p-8 animate-pulse space-y-4">
              <div className="h-6 bg-surface-container-high rounded w-1/3" />
              <div className="h-10 bg-surface-container-high rounded w-2/3" />
              <div className="h-24 bg-surface-container-high rounded" />
            </div>
          ) : !currentOrder ? (
            <div className="rounded-3xl bg-surface-container-lowest p-10 text-center border border-surface-container space-y-4">
              <h1 className="font-serif text-2xl text-primary font-semibold">
                Belum Ada Pesanan Aktif
              </h1>
              <p className="text-sm text-on-surface-variant">
                Mulai pesan kopi favorit Anda untuk melacak proses racikan barista secara langsung.
              </p>
              <Link
                href="/menu"
                className="inline-flex items-center gap-2 px-7 py-3 rounded-full bg-primary text-on-primary text-sm font-semibold hover:bg-primary-container"
              >
                <span>Lihat Daftar Menu</span>
              </Link>
            </div>
          ) : (
            <>
              {/* Header Card: Status & Summary */}
              <section className="rounded-3xl bg-surface-container-low p-6 sm:p-8 shadow-sm space-y-6">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div className="space-y-1">
                    <span className="text-xs font-semibold tracking-wider uppercase text-on-surface-variant">
                      Status Pesanan Langsung
                    </span>
                    <h1
                      data-testid="order-status-headline"
                      className="font-serif text-2xl sm:text-3xl text-primary font-semibold tracking-tight"
                    >
                      {getOrderStatusHeadline(currentOrder.status)}
                    </h1>
                    <div className="flex flex-wrap items-center gap-2 pt-1 text-xs text-on-surface-variant">
                      <span className="font-mono font-semibold text-primary">
                        {currentOrder.invoiceNumber}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{currentOrder.customerName}</span>
                      <span aria-hidden="true">·</span>
                      <span>{formattedDate}</span>
                    </div>
                  </div>

                  <div
                    className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold uppercase tracking-wide ${
                      currentOrder.paymentStatus === 'paid'
                        ? 'bg-primary-fixed text-primary'
                        : currentOrder.status === 'cancelled'
                        ? 'bg-error-container text-on-error-container'
                        : 'bg-secondary-container text-on-secondary-container'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>
                      {currentOrder.paymentStatus === 'paid'
                        ? `LUNAS · ${currentOrder.paymentMethod.toUpperCase()}`
                        : currentOrder.status === 'cancelled'
                        ? 'DIBATALKAN'
                        : `MENUNGGU BAYAR · ${currentOrder.paymentMethod.toUpperCase()}`}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex items-center gap-3.5 p-4 rounded-2xl bg-surface-container-lowest shadow-sm">
                    <div className="flex items-center justify-center w-11 h-11 rounded-full bg-secondary-container text-on-secondary-container shrink-0">
                      <Hourglass className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-[11px] uppercase tracking-wider text-on-surface-variant">
                        Estimasi Siap
                      </p>
                      <p className="font-serif text-lg text-primary font-semibold tabular-nums">
                        {currentOrder.status === 'ready'
                          ? 'Siap Diambil Sekarang'
                          : currentOrder.status === 'completed'
                          ? 'Pesanan Selesai'
                          : currentOrder.status === 'cancelled'
                          ? 'Dibatalkan'
                          : `${currentOrder.estimatedMinutes} - ${currentOrder.estimatedMinutes + 5} Menit`}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3.5 p-4 rounded-2xl bg-surface-container-lowest shadow-sm">
                    <div className="flex items-center justify-center w-11 h-11 rounded-full bg-tertiary-fixed text-tertiary shrink-0">
                      <Store className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-[11px] uppercase tracking-wider text-on-surface-variant">
                        Metode Pengambilan
                      </p>
                      <p className="font-serif text-lg text-primary font-semibold">
                        {currentOrder.serviceType === 'dine_in'
                          ? `Dine-In (${currentOrder.tableNumber || 'Meja'})`
                          : 'Take Away (Bar Kasir)'}
                      </p>
                    </div>
                  </div>
                </div>
              </section>

              {/* Linear 4-Step Horizontal Stepper */}
              <section
                aria-label="Tahapan Pesanan"
                className="rounded-3xl bg-surface-container-low p-6 sm:p-8 shadow-sm"
              >
                <div className="relative">
                  <div className="hidden sm:block absolute top-5 left-10 right-10 h-0.5 bg-surface-container-highest">
                    <div
                      className="h-full bg-primary transition-all duration-500 ease-out"
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-6 sm:gap-2 relative z-10">
                    {[
                      {
                        step: 1,
                        title: '1. Menunggu Bayar',
                        desc:
                          stepIndex > 1
                            ? 'Berhasil diverifikasi'
                            : 'Menunggu konfirmasi',
                        icon: <Clock className="w-4 h-4" />,
                      },
                      {
                        step: 2,
                        title: '2. Diproses Barista',
                        desc:
                          stepIndex === 2
                            ? 'Sedang diracik'
                            : stepIndex > 2
                            ? 'Selesai diracik'
                            : 'Menunggu antrian',
                        icon: <Coffee className="w-4 h-4" />,
                      },
                      {
                        step: 3,
                        title: '3. Siap Diambil',
                        desc:
                          stepIndex === 3
                            ? 'Ambil di bar kasir'
                            : stepIndex > 3
                            ? 'Sudah diserahkan'
                            : 'Menunggu pesanan jadi',
                        icon: <Store className="w-4 h-4" />,
                      },
                      {
                        step: 4,
                        title: '4. Selesai',
                        desc:
                          stepIndex === 4
                            ? 'Pengambilan tuntas'
                            : 'Menunggu selesai',
                        icon: <Check className="w-4 h-4" />,
                      },
                    ].map((s) => {
                      const isDone = stepIndex > s.step || (s.step === 4 && stepIndex === 4);
                      const isActive = stepIndex === s.step && s.step !== 4;
                      const isPending = stepIndex < s.step;

                      return (
                        <div
                          key={s.step}
                          className={`flex sm:flex-col items-center gap-4 sm:gap-2.5 text-left sm:text-center transition-opacity ${
                            isPending ? 'opacity-50' : 'opacity-100'
                          }`}
                        >
                          <div
                            className={`flex items-center justify-center w-10 h-10 rounded-full shrink-0 font-semibold text-sm ${
                              isDone
                                ? 'bg-primary text-on-primary shadow-sm'
                                : isActive
                                ? 'bg-primary-container text-on-primary ring-4 ring-primary/15 shadow-md'
                                : 'bg-surface-container-highest text-on-surface-variant'
                            }`}
                          >
                            {isDone ? (
                              <Check className="w-4 h-4" />
                            ) : isActive ? (
                              s.icon
                            ) : (
                              s.step
                            )}
                          </div>
                          <div>
                            <p className="text-xs font-semibold text-primary">
                              {s.title}
                            </p>
                            <p className="text-[11px] text-on-surface-variant mt-0.5">
                              {s.desc}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </section>

              {/* Visual Botanical Mood Banner */}
              <div className="relative rounded-3xl overflow-hidden bg-surface-container h-44 sm:h-52 shadow-sm flex items-end no-print">
                <Image
                  src="/images/banner-botanical-barista.jpg"
                  alt="Barista Green Cafe meracik kopi pour-over organik"
                  fill
                  sizes="(max-width: 768px) 100vw, 768px"
                  referrerPolicy="no-referrer"
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary/90 via-primary/35 to-transparent" />
                <div className="relative z-10 p-6 sm:p-8 text-on-primary w-full flex items-center justify-between gap-4">
                  <div>
                    <span className="text-[11px] tracking-wider uppercase text-inverse-primary block">
                      Green Cafe Kitchen
                    </span>
                    <p className="font-serif text-lg sm:text-xl text-on-primary font-semibold">
                      Dibuat dari Biji Kopi Organik Pilihan
                    </p>
                  </div>
                  <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-surface/20 backdrop-blur-md text-on-primary text-xs">
                    <Sprout className="w-4 h-4" />
                    <span>Earth-Friendly Kitchen</span>
                  </div>
                </div>
              </div>

              {/* Digital Receipt Card */}
              <section className="rounded-3xl bg-surface-container-lowest p-6 sm:p-8 shadow-sm border border-surface-container space-y-6">
                <div className="flex items-center justify-between pb-4 border-b border-surface-container">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary-fixed text-primary flex items-center justify-center">
                      <ReceiptText className="w-5 h-5" />
                    </div>
                    <div>
                      <h2 className="font-serif text-xl text-primary font-semibold">
                        Rincian Pesanan
                      </h2>
                      <p className="text-xs text-on-surface-variant">
                        Struk Digital · Order ID: {currentOrder.invoiceNumber}
                      </p>
                    </div>
                  </div>
                  <span className="text-xs font-semibold text-primary tabular-nums">
                    {currentOrder.items.reduce((s, i) => s + i.quantity, 0)} Item
                  </span>
                </div>

                <div className="space-y-3.5">
                  {currentOrder.items.map((item) => (
                    <div
                      key={item.id}
                      className="flex items-start justify-between gap-4 p-4 rounded-2xl bg-surface-container-low"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded-md bg-primary text-on-primary text-[11px] font-bold tabular-nums">
                            {item.quantity}x
                          </span>
                          <h3 className="font-serif text-base text-primary font-semibold">
                            {item.name}
                          </h3>
                        </div>
                        <p className="text-xs text-on-surface-variant">
                          {item.variantLabel}
                        </p>
                        {item.notes && (
                          <div className="inline-flex items-center gap-1.5 text-[11px] text-on-surface-variant pt-0.5">
                            <FileText className="w-3.5 h-3.5 text-primary" />
                            <span>Catatan: {item.notes}</span>
                          </div>
                        )}
                      </div>
                      <span className="font-semibold text-sm text-primary whitespace-nowrap tabular-nums">
                        {formatRupiah(item.lineTotal)}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="p-5 rounded-2xl bg-surface-container space-y-2.5 text-sm">
                  <div className="flex items-center justify-between text-on-surface-variant">
                    <span>Subtotal Produk</span>
                    <span className="text-on-surface font-medium tabular-nums">
                      {formatRupiah(currentOrder.subtotal)}
                    </span>
                  </div>
                  {currentOrder.discountAmount > 0 && (
                    <div className="flex items-center justify-between text-secondary font-medium">
                      <span>Diskon ({currentOrder.promoCode})</span>
                      <span className="tabular-nums">
                        -{formatRupiah(currentOrder.discountAmount)}
                      </span>
                    </div>
                  )}
                  <div className="flex items-center justify-between text-on-surface-variant">
                    <span>Pajak Restoran (10%)</span>
                    <span className="text-on-surface font-medium tabular-nums">
                      {formatRupiah(currentOrder.taxAmount)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-on-surface-variant">
                    <span>Kemasan Ramah Lingkungan</span>
                    <span className="text-primary font-semibold">Gratis</span>
                  </div>

                  <div className="pt-3 mt-2 border-t border-outline-variant/40 flex items-baseline justify-between">
                    <div>
                      <span className="text-[11px] uppercase tracking-wider text-on-surface-variant block">
                        Total Tagihan
                      </span>
                      <p className="text-xs text-outline">
                        Termasuk Pajak &amp; Biaya Layanan
                      </p>
                    </div>
                    <span className="font-serif text-2xl text-primary font-bold tabular-nums">
                      {formatRupiah(currentOrder.totalAmount)}
                    </span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3 px-1 text-xs text-on-surface-variant">
                  <div className="flex items-center gap-2">
                    <QrCode className="w-4 h-4 text-primary" />
                    <span>
                      Metode:{' '}
                      <strong className="text-primary uppercase">
                        {currentOrder.paymentMethod}
                      </strong>
                    </span>
                  </div>
                  {currentOrder.trxReference && (
                    <div className="font-mono text-xs text-outline">
                      TRX: <span className="select-all">{currentOrder.trxReference}</span>
                    </div>
                  )}
                </div>
              </section>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 no-print">
                <button
                  type="button"
                  onClick={handleDownloadReceipt}
                  className="w-full sm:w-auto px-7 py-3.5 rounded-full bg-surface-container-high text-primary text-sm font-semibold hover:bg-surface-container-highest transition-colors inline-flex items-center justify-center gap-2"
                >
                  {downloaded ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Struk Siap Dicetak</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4" />
                      <span>Unduh Struk Digital (PDF)</span>
                    </>
                  )}
                </button>
                <Link
                  href="/menu"
                  className="w-full sm:w-auto px-8 py-3.5 rounded-full bg-primary text-on-primary text-sm font-semibold hover:bg-primary-container transition-colors inline-flex items-center justify-center gap-2 shadow-sm"
                >
                  <Store className="w-4 h-4" />
                  <span>Pesan Lagi</span>
                </Link>
              </div>

              {/* Collapsible Order History & Support */}
              <div className="space-y-4 pt-2 no-print">
                {pastOrders.length > 0 && (
                  <div className="rounded-2xl bg-surface-container-low p-4 shadow-sm">
                    <button
                      type="button"
                      aria-expanded={historyOpen}
                      onClick={() => setHistoryOpen((prev) => !prev)}
                      className="w-full flex items-center justify-between text-left"
                    >
                      <div className="flex items-center gap-2.5">
                        <History className="w-4 h-4 text-primary" />
                        <span className="text-sm font-semibold text-primary">
                          Riwayat Pesanan Terakhir ({pastOrders.length})
                        </span>
                      </div>
                      <ChevronDown
                        className={`w-4 h-4 text-on-surface-variant transition-transform ${
                          historyOpen ? 'rotate-180' : ''
                        }`}
                      />
                    </button>

                    {historyOpen && (
                      <div className="pt-4 space-y-2.5">
                        {pastOrders.map((o) => (
                          <Link
                            key={o.id}
                            href={`/pesanan/${o.id}`}
                            className="p-3.5 rounded-xl bg-surface-container-lowest flex items-center justify-between text-sm hover:bg-surface-container transition-colors"
                          >
                            <div className="space-y-0.5">
                              <span className="font-mono font-semibold text-primary">
                                {o.invoiceNumber}
                              </span>
                              <p className="text-xs text-on-surface-variant">
                                {o.customerName} · {o.items.length} Item
                              </p>
                            </div>
                            <div className="text-right">
                              <span className="text-[11px] font-medium text-on-surface-variant block">
                                {getOrderStatusHeadline(o.status)}
                              </span>
                              <span className="text-xs font-semibold text-primary tabular-nums">
                                {formatRupiah(o.totalAmount)}
                              </span>
                            </div>
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-5 rounded-2xl bg-surface-container-low shadow-sm">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-secondary-container text-on-secondary-container flex items-center justify-center shrink-0">
                      <MessageCircle className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-primary">
                        Butuh bantuan langsung?
                      </p>
                      <p className="text-xs text-on-surface-variant">
                        Hubungi tim barista atau customer service Green Cafe
                      </p>
                    </div>
                  </div>
                  <Link
                    href="/menu"
                    className="shrink-0 px-4 py-2 rounded-full bg-surface-container-lowest text-primary hover:bg-surface-container transition-colors text-xs font-semibold inline-flex items-center gap-1.5 shadow-sm"
                  >
                    <span>Tambah Pesanan</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </Link>
                </div>

                <div className="text-center py-3 space-y-1">
                  <div className="inline-flex items-center gap-1.5 text-on-surface-variant text-xs font-semibold">
                    <Sprout className="w-4 h-4 text-primary" />
                    <span>100% Organik &amp; Kemasan Ramah Lingkungan</span>
                  </div>
                  <p className="text-xs text-outline">
                    Green Cafe Peduli Bumi · Nikmati kopi dengan tenang dan sadar lingkungan
                  </p>
                </div>
              </div>
            </>
          )}
        </div>
      </main>
    </div>
  );
}
