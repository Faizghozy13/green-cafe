'use client';

import React, { useCallback, useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import {
  BarChart3,
  CheckCircle2,
  Clock,
  Coffee,
  FileText,
  LogOut,
  Plus,
  Printer,
  ReceiptText,
  RefreshCw,
  Search,
  ShoppingBag,
  Sprout,
  TrendingUp,
  UtensilsCrossed,
  X,
} from 'lucide-react';
import { INITIAL_MENU_ITEMS } from '@/lib/menu-data';
import {
  computeDashboardMetrics,
  formatRupiah,
  getOrderStatusHeadline,
} from '@/lib/order-logic';
import type {
  MenuCategory,
  MenuItem,
  Order,
  OrderStatus,
  PaymentMethod,
  Reservation,
  ReservationStatus,
  ServiceType,
} from '@/lib/types';
import { useRealtimeSync } from '@/hooks/use-realtime-sync';

type DashboardTab = 'pesanan' | 'kelola-menu' | 'reservasi' | 'laporan';
type QueueFilter = 'all' | 'pending_payment' | 'preparing' | 'ready' | 'completed';
type SortMode = 'oldest' | 'newest' | 'highest';

export function DashboardView() {
  const [activeTab, setActiveTab] = useState<DashboardTab>('pesanan');
  const [orders, setOrders] = useState<Order[]>([]);
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [menuItems, setMenuItems] = useState<MenuItem[]>(INITIAL_MENU_ITEMS);
  const [loading, setLoading] = useState(true);
  const [lastSyncText, setLastSyncText] = useState('Baru saja');
  const [clockText, setClockText] = useState('--:--:-- WIB');

  // Queue filters
  const [queueFilter, setQueueFilter] = useState<QueueFilter>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortMode, setSortMode] = useState<SortMode>('newest');

  // Menu management state
  const [menuSearch, setMenuSearch] = useState('');
  const [newMenuOpen, setNewMenuOpen] = useState(false);
  const [newMenuName, setNewMenuName] = useState('');
  const [newMenuCategory, setNewMenuCategory] = useState<MenuCategory>('kopi');
  const [newMenuSubcategory, setNewMenuSubcategory] = useState('Espresso Based');
  const [newMenuPrice, setNewMenuPrice] = useState('25000');
  const [newMenuDesc, setNewMenuDesc] = useState('');

  // POS Walk-in order modal
  const [posOpen, setPosOpen] = useState(false);
  const [posName, setPosName] = useState('');
  const [posService, setPosService] = useState<ServiceType>('take_away');
  const [posTable, setPosTable] = useState('Meja 01');
  const [posPayment, setPosPayment] = useState<PaymentMethod>('cash');
  const [posSelectedMenuId, setPosSelectedMenuId] = useState('coffee-aren-latte');
  const [posQty, setPosQty] = useState(1);
  const [posNotes, setPosNotes] = useState('');
  const [posSubmitting, setPosSubmitting] = useState(false);

  // Ticket print modal
  const [ticketOrder, setTicketOrder] = useState<Order | null>(null);

  const loadAllData = useCallback(async () => {
    try {
      const [ordersRes, resvRes, menuRes] = await Promise.all([
        fetch('/api/orders', { cache: 'no-store' }),
        fetch('/api/reservations', { cache: 'no-store' }),
        fetch('/api/menu', { cache: 'no-store' }),
      ]);

      if (ordersRes.ok) {
        const d = await ordersRes.json();
        if (Array.isArray(d.orders)) setOrders(d.orders);
      }
      if (resvRes.ok) {
        const d = await resvRes.json();
        if (Array.isArray(d.reservations)) setReservations(d.reservations);
      }
      if (menuRes.ok) {
        const d = await menuRes.json();
        if (Array.isArray(d.items)) setMenuItems(d.items);
      }

      setLastSyncText(
        new Date().toLocaleTimeString('id-ID', {
          hour: '2-digit',
          minute: '2-digit',
        })
      );
    } catch {
      // keep previous data on temporary network failure
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const id = setTimeout(() => {
      void loadAllData();
    }, 0);
    return () => clearTimeout(id);
  }, [loadAllData]);

  useRealtimeSync({
    channels: ['orders', 'reservations', 'menu'],
    onUpdate: loadAllData,
  });

  useEffect(() => {
    const updateClock = () => {
      setClockText(
        new Date().toLocaleTimeString('id-ID', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        }) + ' WIB'
      );
    };
    const initId = setTimeout(updateClock, 0);
    const timer = setInterval(updateClock, 1000);
    return () => {
      clearTimeout(initId);
      clearInterval(timer);
    };
  }, []);

  const metrics = useMemo(
    () => computeDashboardMetrics(orders, reservations, menuItems),
    [orders, reservations, menuItems]
  );

  const filteredOrders = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    const list = orders.filter((o) => {
      if (queueFilter === 'all') {
        if (o.status === 'cancelled') return false;
      } else if (o.status !== queueFilter) {
        return false;
      }
      if (!q) return true;
      return (
        o.invoiceNumber.toLowerCase().includes(q) ||
        o.customerName.toLowerCase().includes(q)
      );
    });

    return [...list].sort((a, b) => {
      if (sortMode === 'highest') return b.totalAmount - a.totalAmount;
      const diff =
        new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      return sortMode === 'oldest' ? diff : -diff;
    });
  }, [orders, queueFilter, searchQuery, sortMode]);

  const handleOrderAction = async (
    orderId: string,
    action: 'confirm_payment' | 'mark_ready' | 'complete' | 'cancel'
  ) => {
    const res = await fetch(`/api/orders/${orderId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action }),
    });
    if (res.ok) {
      await loadAllData();
    }
  };

  const handleToggleMenuStock = async (item: MenuItem) => {
    const res = await fetch(`/api/menu/${item.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ isAvailable: !item.isAvailable }),
    });
    if (res.ok) {
      await loadAllData();
    }
  };

  const handleCreateMenu = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMenuName.trim()) return;
    const res = await fetch('/api/menu', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: newMenuName,
        category: newMenuCategory,
        subcategory: newMenuSubcategory,
        price: Number(newMenuPrice) || 20000,
        description: newMenuDesc,
      }),
    });
    if (res.ok) {
      setNewMenuName('');
      setNewMenuDesc('');
      setNewMenuOpen(false);
      await loadAllData();
    }
  };

  const handleCreatePosOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!posName.trim()) return;
    setPosSubmitting(true);
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerName: posName.trim(),
          serviceType: posService,
          tableNumber: posService === 'dine_in' ? posTable : null,
          paymentMethod: posPayment,
          items: [
            {
              menuItemId: posSelectedMenuId,
              quantity: posQty,
              variantLabel: 'Standar Kasir',
              notes: posNotes,
            },
          ],
        }),
      });
      if (res.ok) {
        setPosName('');
        setPosNotes('');
        setPosQty(1);
        setPosOpen(false);
        await loadAllData();
      }
    } finally {
      setPosSubmitting(false);
    }
  };

  const handleReservationStatus = async (
    id: string,
    status: ReservationStatus
  ) => {
    const res = await fetch(`/api/reservations/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    if (res.ok) {
      await loadAllData();
    }
  };

  const statusCounts = useMemo(() => {
    const counts: Record<OrderStatus | 'nonCancelled', number> = {
      nonCancelled: 0,
      pending_payment: 0,
      preparing: 0,
      ready: 0,
      completed: 0,
      cancelled: 0,
    };
    for (const o of orders) {
      counts[o.status] += 1;
      if (o.status !== 'cancelled') counts.nonCancelled += 1;
    }
    return counts;
  }, [orders]);

  return (
    <div className="min-h-screen bg-surface text-on-surface flex flex-col lg:flex-row">
      {/* Left Sidebar (Desktop) */}
      <aside className="lg:fixed lg:left-0 lg:top-0 lg:h-full lg:w-72 bg-surface-container-low border-b lg:border-b-0 lg:border-r border-surface-container-high z-40 flex flex-col justify-between py-5 px-4">
        <div className="flex flex-col gap-5">
          <div className="px-3 flex items-center justify-between lg:justify-start gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary-container text-on-primary flex items-center justify-center shrink-0">
                <Sprout className="w-5 h-5" />
              </div>
              <div>
                <span className="font-serif text-lg text-primary font-semibold block leading-none">
                  Green Cafe
                </span>
                <span className="text-[11px] text-on-surface-variant tracking-wider uppercase mt-1 block">
                  Atelier &amp; Roastery
                </span>
              </div>
            </div>
            <Link
              href="/"
              className="lg:hidden text-xs font-semibold text-secondary"
            >
              Ke Toko →
            </Link>
          </div>

          <div className="h-px bg-surface-container-high mx-2 hidden lg:block" />

          <nav
            className="flex lg:flex-col gap-1.5 overflow-x-auto no-scrollbar"
            aria-label="Menu Dashboard Barista"
          >
            {(
              [
                {
                  id: 'pesanan',
                  label: 'Pesanan',
                  icon: <ReceiptText className="w-4 h-4" />,
                },
                {
                  id: 'kelola-menu',
                  label: 'Kelola Menu',
                  icon: <Coffee className="w-4 h-4" />,
                },
                {
                  id: 'reservasi',
                  label: 'Reservasi',
                  icon: <UtensilsCrossed className="w-4 h-4" />,
                },
                {
                  id: 'laporan',
                  label: 'Laporan',
                  icon: <BarChart3 className="w-4 h-4" />,
                },
              ] as const
            ).map((nav) => {
              const active = activeTab === nav.id;
              return (
                <button
                  key={nav.id}
                  type="button"
                  onClick={() => setActiveTab(nav.id)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold whitespace-nowrap shrink-0 transition-all ${
                    active
                      ? 'bg-primary-container text-on-primary shadow-sm'
                      : 'text-on-surface-variant hover:bg-surface-container-high hover:text-on-surface'
                  }`}
                >
                  {nav.icon}
                  <span>{nav.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="hidden lg:flex p-3 bg-surface-container rounded-xl items-center justify-between gap-2">
          <div className="min-w-0">
            <span className="text-xs font-semibold text-on-surface block truncate">
              Aditia Barista
            </span>
            <span className="text-[11px] text-on-surface-variant block truncate">
              Shift Pagi · Kasir Utama
            </span>
          </div>
          <Link
            href="/"
            aria-label="Kembali ke beranda pelanggan"
            className="w-8 h-8 rounded-full flex items-center justify-center text-on-surface-variant hover:bg-surface-container-highest hover:text-on-surface transition-colors shrink-0"
          >
            <LogOut className="w-4 h-4" />
          </Link>
        </div>
      </aside>

      {/* Main Content Shell */}
      <div className="lg:pl-72 flex-1 flex flex-col min-h-screen">
        {/* Top Header */}
        <header className="sticky top-0 h-16 bg-surface/90 backdrop-blur-md z-30 px-6 lg:px-8 flex items-center justify-between border-b border-surface-container">
          <div className="flex items-center gap-3 text-xs">
            <span className="font-semibold text-primary">Buka · Kasir Utama</span>
            <span className="text-outline-variant hidden sm:inline">/</span>
            <span className="hidden sm:inline text-on-surface-variant">
              Operasional Lantai 1
            </span>
          </div>

          <div className="flex items-center gap-3 sm:gap-4">
            <div className="flex items-center gap-2 text-xs text-on-surface px-3 py-1.5 rounded-full bg-surface-container-low tabular-nums whitespace-nowrap shrink-0">
              <Clock className="w-3.5 h-3.5 text-on-surface-variant shrink-0" />
              <span className="font-mono">{clockText}</span>
            </div>
            <Link
              href="/menu"
              className="text-xs font-semibold text-primary hover:text-secondary transition-colors whitespace-nowrap"
            >
              Lihat Menu Pelanggan
            </Link>
          </div>
        </header>

        <main className="flex-1 px-6 lg:px-8 py-8 max-w-7xl mx-auto w-full space-y-8">
          {/* Page Header */}
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-5">
            <div>
              <span className="text-xs font-semibold text-secondary uppercase tracking-widest">
                Operasional · Sinkronisasi Real-Time
              </span>
              <h1 className="font-serif text-3xl text-primary font-semibold tracking-tight mt-1">
                Dashboard Operasional
              </h1>
              <p className="text-sm text-on-surface-variant mt-1">
                Pantau antrian pesanan, konfirmasi kasir, reservasi meja, dan ketersediaan menu secara langsung.
              </p>
            </div>

            <div className="flex items-center gap-3 flex-wrap">
              <button
                type="button"
                onClick={loadAllData}
                className="flex items-center gap-2 px-3.5 py-2 rounded-full bg-surface-container-low text-on-surface-variant hover:text-primary text-xs font-medium"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Sinkron: {lastSyncText}</span>
              </button>
              <button
                type="button"
                onClick={() => setPosOpen(true)}
                className="inline-flex items-center gap-2 bg-primary-container text-on-primary px-5 py-2.5 rounded-full text-sm font-semibold hover:bg-primary transition-colors shadow-sm"
              >
                <Plus className="w-4 h-4" />
                <span>Pesanan Kasir Baru</span>
              </button>
            </div>
          </div>

          {/* Top KPI Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 rounded-2xl bg-surface-container-lowest border border-surface-container flex flex-col justify-between">
              <span className="text-xs font-semibold text-on-surface-variant">
                Pesanan Aktif
              </span>
              <div className="mt-3 flex items-baseline justify-between">
                <span className="font-serif text-4xl text-primary font-semibold tabular-nums">
                  {metrics.activeOrdersCount}
                </span>
                <span className="text-xs text-primary font-medium">
                  Sedang Berjalan
                </span>
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-surface-container-lowest border border-surface-container flex flex-col justify-between">
              <span className="text-xs font-semibold text-on-surface-variant">
                Menunggu Kasir
              </span>
              <div className="mt-3 flex items-baseline justify-between">
                <span className="font-serif text-4xl text-primary font-semibold tabular-nums">
                  {metrics.awaitingCashierCount}
                </span>
                <span className="text-xs text-secondary font-semibold">
                  Perlu Konfirmasi
                </span>
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-surface-container-lowest border border-surface-container flex flex-col justify-between">
              <span className="text-xs font-semibold text-on-surface-variant">
                Reservasi Aktif
              </span>
              <div className="mt-3 flex items-baseline justify-between">
                <span className="font-serif text-4xl text-primary font-semibold tabular-nums">
                  {metrics.todayReservationsCount}
                </span>
                <span className="text-xs text-on-surface-variant">
                  Meja Terjadwal
                </span>
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-surface-container-lowest border border-surface-container flex flex-col justify-between">
              <span className="text-xs font-semibold text-on-surface-variant">
                Pendapatan Lunas
              </span>
              <div className="mt-3">
                <span className="font-serif text-2xl text-primary font-semibold tabular-nums block">
                  {formatRupiah(metrics.paidRevenue)}
                </span>
                <span className="text-xs text-primary font-medium inline-flex items-center gap-1 mt-1">
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>Terverifikasi hari ini</span>
                </span>
              </div>
            </div>
          </div>

          {/* ==================== TAB 1: PESANAN ==================== */}
          {activeTab === 'pesanan' && (
            <section className="space-y-6">
              <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4">
                <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
                  {(
                    [
                      {
                        id: 'all',
                        label: `Semua (${statusCounts.nonCancelled})`,
                      },
                      {
                        id: 'pending_payment',
                        label: `Menunggu Bayar (${statusCounts.pending_payment})`,
                      },
                      {
                        id: 'preparing',
                        label: `Diproses (${statusCounts.preparing})`,
                      },
                      {
                        id: 'ready',
                        label: `Siap Diambil (${statusCounts.ready})`,
                      },
                      {
                        id: 'completed',
                        label: `Selesai (${statusCounts.completed})`,
                      },
                    ] as const
                  ).map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => setQueueFilter(t.id)}
                      className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
                        queueFilter === t.id
                          ? 'bg-primary-container text-on-primary'
                          : 'bg-surface-container text-on-surface-variant hover:text-on-surface'
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-3">
                  <div className="relative flex-1 sm:w-64">
                    <Search className="w-4 h-4 text-on-surface-variant absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Cari No. Invoice / Nama..."
                      className="w-full pl-9 pr-4 py-2 rounded-full bg-surface-container-lowest border border-surface-container text-xs text-on-surface placeholder:text-outline focus:outline-none"
                    />
                  </div>
                  <select
                    aria-label="Urutkan pesanan"
                    value={sortMode}
                    onChange={(e) => setSortMode(e.target.value as SortMode)}
                    className="px-3.5 py-2 rounded-full bg-surface-container-lowest border border-surface-container text-xs font-medium text-on-surface focus:outline-none"
                  >
                    <option value="oldest">Terlama ke Terbaru</option>
                    <option value="newest">Terbaru ke Terlama</option>
                    <option value="highest">Nominal Tertinggi</option>
                  </select>
                </div>
              </div>

              {loading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[1, 2, 3].map((i) => (
                    <div
                      key={i}
                      className="h-72 rounded-2xl bg-surface-container-low animate-pulse"
                    />
                  ))}
                </div>
              ) : filteredOrders.length === 0 ? (
                <div className="p-12 rounded-3xl bg-surface-container-lowest border border-surface-container text-center">
                  <p className="font-serif text-xl text-primary font-semibold">
                    Tidak ada pesanan pada filter ini
                  </p>
                  <p className="text-xs text-on-surface-variant mt-1">
                    Pesanan baru dari pelanggan akan muncul otomatis di sini.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 items-start">
                  {filteredOrders.map((order) => {
                    const orderTime = new Date(
                      order.createdAt
                    ).toLocaleTimeString('id-ID', {
                      hour: '2-digit',
                      minute: '2-digit',
                    });

                    return (
                      <article
                        key={order.id}
                        className="bg-surface-container-lowest rounded-2xl p-6 border border-surface-container shadow-sm flex flex-col justify-between gap-5"
                      >
                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <Link
                                href={`/pesanan/${order.id}`}
                                className="font-mono font-semibold text-primary text-xs hover:underline"
                              >
                                {order.invoiceNumber}
                              </Link>
                              <span className="text-xs text-on-surface-variant flex items-center gap-1 mt-0.5 tabular-nums">
                                <Clock className="w-3.5 h-3.5" />
                                {orderTime} WIB
                              </span>
                            </div>

                            <span
                              className={`text-[11px] font-semibold px-2.5 py-1 rounded-full ${
                                order.status === 'pending_payment'
                                  ? 'bg-secondary-container text-on-secondary-container'
                                  : order.status === 'preparing'
                                  ? 'bg-primary-fixed text-on-primary-fixed'
                                  : order.status === 'ready'
                                  ? 'bg-tertiary-fixed text-on-tertiary-fixed'
                                  : 'bg-surface-container text-on-surface-variant'
                              }`}
                            >
                              {getOrderStatusHeadline(order.status)}
                            </span>
                          </div>

                          <div>
                            <div className="flex items-center justify-between gap-2">
                              <h2 className="font-serif text-lg text-primary font-semibold">
                                {order.customerName}
                              </h2>
                              <span className="text-xs font-medium text-on-surface-variant">
                                {order.serviceType === 'dine_in'
                                  ? `Dine-In · ${order.tableNumber || 'Meja'}`
                                  : 'Take Away'}
                              </span>
                            </div>
                            <p className="text-xs font-medium text-secondary mt-0.5">
                              {order.paymentStatus === 'paid'
                                ? `Lunas · ${order.paymentMethod.toUpperCase()}`
                                : `Belum Bayar · ${order.paymentMethod.toUpperCase()}`}
                            </p>
                          </div>

                          <div className="p-4 rounded-xl bg-surface-container-low space-y-2.5">
                            {order.items.map((item) => (
                              <div
                                key={item.id}
                                className="flex items-start justify-between gap-2 text-xs"
                              >
                                <div className="min-w-0">
                                  <span className="font-semibold text-on-surface block">
                                    {item.quantity}x {item.name}
                                  </span>
                                  <span className="text-on-surface-variant block">
                                    {item.variantLabel}
                                  </span>
                                  {item.notes && (
                                    <span className="text-secondary italic flex items-center gap-1 mt-0.5">
                                      <FileText className="w-3 h-3 shrink-0" />
                                      {item.notes}
                                    </span>
                                  )}
                                </div>
                                <span className="font-mono text-primary whitespace-nowrap tabular-nums">
                                  {formatRupiah(item.lineTotal)}
                                </span>
                              </div>
                            ))}
                          </div>

                          <div className="flex items-center justify-between px-1">
                            <span className="text-xs text-on-surface-variant uppercase tracking-wider">
                              Total Tagihan
                            </span>
                            <span className="font-serif text-lg font-bold text-primary tabular-nums">
                              {formatRupiah(order.totalAmount)}
                            </span>
                          </div>
                        </div>

                        <div className="flex flex-col gap-2 pt-2 border-t border-surface-container">
                          {order.status === 'pending_payment' && (
                            <button
                              type="button"
                              onClick={() =>
                                handleOrderAction(order.id, 'confirm_payment')
                              }
                              className="w-full py-2.5 px-4 rounded-full bg-primary-container text-on-primary text-xs font-semibold hover:bg-primary transition-colors flex items-center justify-center gap-1.5"
                            >
                              <CheckCircle2 className="w-4 h-4" />
                              <span>Konfirmasi Pembayaran</span>
                            </button>
                          )}

                          {order.status === 'preparing' && (
                            <button
                              type="button"
                              onClick={() =>
                                handleOrderAction(order.id, 'mark_ready')
                              }
                              className="w-full py-2.5 px-4 rounded-full bg-primary-container text-on-primary text-xs font-semibold hover:bg-primary transition-colors flex items-center justify-center gap-1.5"
                            >
                              <ShoppingBag className="w-4 h-4" />
                              <span>Tandai Siap Diambil</span>
                            </button>
                          )}

                          {order.status === 'ready' && (
                            <button
                              type="button"
                              onClick={() =>
                                handleOrderAction(order.id, 'complete')
                              }
                              className="w-full py-2.5 px-4 rounded-full bg-primary text-on-primary text-xs font-semibold hover:bg-primary-container transition-colors flex items-center justify-center gap-1.5"
                            >
                              <CheckCircle2 className="w-4 h-4" />
                              <span>Selesaikan</span>
                            </button>
                          )}

                          <div className="flex items-center justify-between gap-2">
                            <button
                              type="button"
                              onClick={() => setTicketOrder(order)}
                              className="flex-1 py-2 px-3 rounded-full text-on-surface-variant hover:bg-surface-container text-xs font-medium inline-flex items-center justify-center gap-1.5"
                            >
                              <Printer className="w-3.5 h-3.5" />
                              <span>Tiket Barista</span>
                            </button>

                            {(order.status === 'pending_payment' ||
                              order.status === 'preparing') && (
                              <button
                                type="button"
                                onClick={() =>
                                  handleOrderAction(order.id, 'cancel')
                                }
                                className="py-2 px-3 rounded-full text-error hover:bg-error-container/30 text-xs font-medium"
                              >
                                Batalkan
                              </button>
                            )}
                          </div>
                        </div>
                      </article>
                    );
                  })}
                </div>
              )}
            </section>
          )}

          {/* ==================== TAB 2: KELOLA MENU ==================== */}
          {activeTab === 'kelola-menu' && (
            <section className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="relative w-full sm:w-80">
                  <Search className="w-4 h-4 text-outline absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={menuSearch}
                    onChange={(e) => setMenuSearch(e.target.value)}
                    placeholder="Cari nama menu atau kategori..."
                    className="w-full pl-10 pr-4 py-2.5 rounded-full bg-surface-container-lowest border border-surface-container text-xs text-on-surface"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => setNewMenuOpen(true)}
                  className="px-5 py-2.5 rounded-full bg-primary-container text-on-primary text-xs font-semibold hover:bg-primary transition-colors inline-flex items-center gap-1.5 self-start"
                >
                  <Plus className="w-4 h-4" />
                  <span>Tambah Menu Baru</span>
                </button>
              </div>

              <div className="bg-surface-container-lowest rounded-2xl border border-surface-container overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-surface-container-low text-on-surface-variant border-b border-surface-container">
                      <tr>
                        <th className="py-3.5 px-5 font-semibold">Menu</th>
                        <th className="py-3.5 px-4 font-semibold">Kategori</th>
                        <th className="py-3.5 px-4 font-semibold">Subkategori</th>
                        <th className="py-3.5 px-4 font-semibold text-right">
                          Harga
                        </th>
                        <th className="py-3.5 px-5 font-semibold text-right">
                          Status Stok
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-surface-container">
                      {menuItems
                        .filter((m) => {
                          const q = menuSearch.toLowerCase().trim();
                          if (!q) return true;
                          return (
                            m.name.toLowerCase().includes(q) ||
                            m.subcategory.toLowerCase().includes(q)
                          );
                        })
                        .map((item) => (
                          <tr
                            key={item.id}
                            className="hover:bg-surface-container-low/50 transition-colors"
                          >
                            <td className="py-3 px-5 font-semibold text-primary">
                              {item.name}
                            </td>
                            <td className="py-3 px-4 capitalize text-on-surface-variant">
                              {item.category}
                            </td>
                            <td className="py-3 px-4 text-on-surface-variant">
                              {item.subcategory}
                            </td>
                            <td className="py-3 px-4 text-right font-mono text-primary tabular-nums">
                              {formatRupiah(item.price)}
                            </td>
                            <td className="py-3 px-5 text-right">
                              <button
                                type="button"
                                onClick={() => handleToggleMenuStock(item)}
                                className={`px-3 py-1 rounded-full text-[11px] font-semibold transition-colors ${
                                  item.isAvailable
                                    ? 'bg-primary-fixed text-on-primary-fixed hover:bg-primary-fixed-dim'
                                    : 'bg-error-container text-on-error-container'
                                }`}
                              >
                                {item.isAvailable ? 'Tersedia' : 'Habis'}
                              </button>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </section>
          )}

          {/* ==================== TAB 3: RESERVASI ==================== */}
          {activeTab === 'reservasi' && (
            <section className="space-y-4">
              <h2 className="font-serif text-xl text-primary font-semibold">
                Daftar Reservasi Meja Dine-In
              </h2>
              {reservations.length === 0 ? (
                <div className="p-10 rounded-3xl bg-surface-container-lowest border border-surface-container text-center text-sm text-on-surface-variant">
                  Belum ada reservasi masuk.
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                  {reservations.map((r) => (
                    <div
                      key={r.id}
                      className="bg-surface-container-lowest rounded-2xl p-5 border border-surface-container space-y-4"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="font-mono text-xs text-secondary font-semibold">
                            {r.reservationCode}
                          </span>
                          <h3 className="font-serif text-lg text-primary font-semibold mt-0.5">
                            {r.customerName}
                          </h3>
                          <p className="text-xs text-on-surface-variant">
                            {r.customerPhone}
                          </p>
                        </div>
                        <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-surface-container text-primary">
                          {r.tableNumber}
                        </span>
                      </div>

                      <div className="p-3 rounded-xl bg-surface-container-low text-xs space-y-1">
                        <div className="flex justify-between">
                          <span className="text-outline">Jadwal</span>
                          <span className="font-semibold text-primary tabular-nums">
                            {r.reservationDate} · {r.reservationTime} WIB
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-outline">Tamu &amp; Area</span>
                          <span className="font-semibold text-primary">
                            {r.guestCount} Org · {r.area}
                          </span>
                        </div>
                        {r.notes && (
                          <p className="text-secondary italic pt-1">
                            Catatan: {r.notes}
                          </p>
                        )}
                      </div>

                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-semibold capitalize text-primary">
                          Status: {r.status}
                        </span>
                        <div className="flex items-center gap-1.5">
                          {r.status === 'confirmed' && (
                            <button
                              type="button"
                              onClick={() =>
                                handleReservationStatus(r.id, 'seated')
                              }
                              className="px-3 py-1.5 rounded-full bg-primary-container text-on-primary text-xs font-semibold"
                            >
                              Check-In
                            </button>
                          )}
                          {r.status === 'seated' && (
                            <button
                              type="button"
                              onClick={() =>
                                handleReservationStatus(r.id, 'completed')
                              }
                              className="px-3 py-1.5 rounded-full bg-primary text-on-primary text-xs font-semibold"
                            >
                              Selesai
                            </button>
                          )}
                          {r.status !== 'completed' &&
                            r.status !== 'cancelled' && (
                              <button
                                type="button"
                                onClick={() =>
                                  handleReservationStatus(r.id, 'cancelled')
                                }
                                className="px-3 py-1.5 rounded-full text-error hover:bg-error-container/30 text-xs font-medium"
                              >
                                Batal
                              </button>
                            )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </section>
          )}

          {/* ==================== TAB 4: LAPORAN ==================== */}
          {activeTab === 'laporan' && (
            <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-surface-container-lowest rounded-2xl p-6 border border-surface-container space-y-4">
                <h2 className="font-serif text-xl text-primary font-semibold">
                  Pendapatan per Kategori
                </h2>
                <div className="space-y-3">
                  {(
                    [
                      { key: 'kopi', label: 'Kopi & Seduhan' },
                      { key: 'non-kopi', label: 'Non-Kopi & Mocktail' },
                      { key: 'makanan', label: 'Makanan, Snack & Pancong' },
                    ] as const
                  ).map((row) => {
                    const amount = metrics.categoryRevenue[row.key];
                    const totalCat =
                      metrics.categoryRevenue.kopi +
                      metrics.categoryRevenue['non-kopi'] +
                      metrics.categoryRevenue.makanan;
                    const pct =
                      totalCat > 0 ? Math.round((amount / totalCat) * 100) : 0;

                    return (
                      <div key={row.key} className="space-y-1.5">
                        <div className="flex justify-between text-xs font-semibold text-primary">
                          <span>{row.label}</span>
                          <span className="tabular-nums">
                            {formatRupiah(amount)} ({pct}%)
                          </span>
                        </div>
                        <div className="h-2.5 rounded-full bg-surface-container overflow-hidden">
                          <div
                            className="h-full bg-primary-container rounded-full"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="bg-surface-container-lowest rounded-2xl p-6 border border-surface-container space-y-4">
                <h2 className="font-serif text-xl text-primary font-semibold">
                  Menu Terlaris
                </h2>
                {metrics.topItems.length === 0 ? (
                  <p className="text-xs text-on-surface-variant">
                    Belum ada transaksi lunas tercatat.
                  </p>
                ) : (
                  <div className="divide-y divide-surface-container">
                    {metrics.topItems.map((item) => (
                      <div
                        key={item.name}
                        className="py-3 flex items-center justify-between text-xs"
                      >
                        <div>
                          <span className="font-semibold text-primary block">
                            {item.name}
                          </span>
                          <span className="text-on-surface-variant">
                            {item.quantity} porsi terjual
                          </span>
                        </div>
                        <span className="font-mono font-semibold text-primary tabular-nums">
                          {formatRupiah(item.revenue)}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </section>
          )}
        </main>
      </div>

      {/* POS New Order Modal */}
      {posOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-primary/45 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-labelledby="pos-modal-title"
        >
          <form
            onSubmit={handleCreatePosOrder}
            className="w-full max-w-md bg-surface-container-lowest rounded-3xl p-6 shadow-2xl space-y-4 relative"
          >
            <button
              type="button"
              aria-label="Tutup modal POS"
              onClick={() => setPosOpen(false)}
              className="absolute top-5 right-5 w-8 h-8 rounded-full bg-surface-container flex items-center justify-center text-on-surface-variant"
            >
              <X className="w-4 h-4" />
            </button>

            <h2
              id="pos-modal-title"
              className="font-serif text-2xl text-primary font-semibold"
            >
              Pesanan Kasir Baru
            </h2>

            <div>
              <label
                htmlFor="pos-name"
                className="text-xs font-semibold text-primary block mb-1"
              >
                Nama Pelanggan *
              </label>
              <input
                id="pos-name"
                type="text"
                required
                value={posName}
                onChange={(e) => setPosName(e.target.value)}
                placeholder="Nama tamu / pemesan"
                className="w-full px-3.5 py-2.5 rounded-xl bg-surface-container-low text-sm text-on-surface"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label
                  htmlFor="pos-service"
                  className="text-xs font-semibold text-primary block mb-1"
                >
                  Layanan
                </label>
                <select
                  id="pos-service"
                  value={posService}
                  onChange={(e) => setPosService(e.target.value as ServiceType)}
                  className="w-full px-3 py-2.5 rounded-xl bg-surface-container-low text-xs text-on-surface"
                >
                  <option value="take_away">Take Away</option>
                  <option value="dine_in">Dine-In</option>
                </select>
              </div>
              {posService === 'dine_in' ? (
                <div>
                  <label
                    htmlFor="pos-table"
                    className="text-xs font-semibold text-primary block mb-1"
                  >
                    Nomor Meja
                  </label>
                  <select
                    id="pos-table"
                    value={posTable}
                    onChange={(e) => setPosTable(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl bg-surface-container-low text-xs text-on-surface"
                  >
                    {[
                      'Meja 01',
                      'Meja 02',
                      'Meja 03',
                      'Meja 04',
                      'Meja 05',
                      'Meja 06',
                    ].map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </div>
              ) : (
                <div>
                  <label
                    htmlFor="pos-payment"
                    className="text-xs font-semibold text-primary block mb-1"
                  >
                    Pembayaran
                  </label>
                  <select
                    id="pos-payment"
                    value={posPayment}
                    onChange={(e) =>
                      setPosPayment(e.target.value as PaymentMethod)
                    }
                    className="w-full px-3 py-2.5 rounded-xl bg-surface-container-low text-xs text-on-surface"
                  >
                    <option value="cash">Tunai Kasir</option>
                    <option value="qris">QRIS</option>
                    <option value="card">Debit / Kartu</option>
                  </select>
                </div>
              )}
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="col-span-2">
                <label
                  htmlFor="pos-menu"
                  className="text-xs font-semibold text-primary block mb-1"
                >
                  Pilih Menu
                </label>
                <select
                  id="pos-menu"
                  value={posSelectedMenuId}
                  onChange={(e) => setPosSelectedMenuId(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-surface-container-low text-xs text-on-surface"
                >
                  {menuItems
                    .filter((m) => m.isAvailable)
                    .map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.name} ({formatRupiah(m.price)})
                      </option>
                    ))}
                </select>
              </div>
              <div>
                <label
                  htmlFor="pos-qty"
                  className="text-xs font-semibold text-primary block mb-1"
                >
                  Jumlah
                </label>
                <input
                  id="pos-qty"
                  type="number"
                  min={1}
                  max={50}
                  value={posQty}
                  onChange={(e) => setPosQty(Math.max(1, Number(e.target.value)))}
                  className="w-full px-3 py-2.5 rounded-xl bg-surface-container-low text-xs text-on-surface"
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="pos-notes"
                className="text-xs font-semibold text-primary block mb-1"
              >
                Catatan
              </label>
              <input
                id="pos-notes"
                type="text"
                value={posNotes}
                onChange={(e) => setPosNotes(e.target.value)}
                placeholder="Catatan barista..."
                className="w-full px-3.5 py-2.5 rounded-xl bg-surface-container-low text-xs text-on-surface"
              />
            </div>

            <button
              type="submit"
              disabled={posSubmitting}
              className="w-full py-3 rounded-full bg-primary text-on-primary text-sm font-semibold hover:bg-primary-container"
            >
              {posSubmitting ? 'Menyimpan...' : 'Buat Pesanan Sekarang'}
            </button>
          </form>
        </div>
      )}

      {/* Add New Menu Modal */}
      {newMenuOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-primary/45 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
        >
          <form
            onSubmit={handleCreateMenu}
            className="w-full max-w-md bg-surface-container-lowest rounded-3xl p-6 shadow-2xl space-y-4 relative"
          >
            <button
              type="button"
              aria-label="Tutup modal tambah menu"
              onClick={() => setNewMenuOpen(false)}
              className="absolute top-5 right-5 w-8 h-8 rounded-full bg-surface-container flex items-center justify-center text-on-surface-variant"
            >
              <X className="w-4 h-4" />
            </button>
            <h2 className="font-serif text-2xl text-primary font-semibold">
              Tambah Menu Baru
            </h2>
            <div>
              <label className="text-xs font-semibold text-primary block mb-1">
                Nama Menu *
              </label>
              <input
                type="text"
                required
                value={newMenuName}
                onChange={(e) => setNewMenuName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-surface-container-low text-sm"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-primary block mb-1">
                  Kategori
                </label>
                <select
                  value={newMenuCategory}
                  onChange={(e) =>
                    setNewMenuCategory(e.target.value as MenuCategory)
                  }
                  className="w-full px-3 py-2.5 rounded-xl bg-surface-container-low text-xs"
                >
                  <option value="kopi">Kopi</option>
                  <option value="non-kopi">Non-Kopi</option>
                  <option value="makanan">Makanan</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-semibold text-primary block mb-1">
                  Harga (Rp)
                </label>
                <input
                  type="number"
                  min={1000}
                  step={500}
                  value={newMenuPrice}
                  onChange={(e) => setNewMenuPrice(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-surface-container-low text-xs"
                />
              </div>
            </div>
            <div>
              <label className="text-xs font-semibold text-primary block mb-1">
                Subkategori
              </label>
              <input
                type="text"
                value={newMenuSubcategory}
                onChange={(e) => setNewMenuSubcategory(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-surface-container-low text-xs"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-primary block mb-1">
                Deskripsi
              </label>
              <input
                type="text"
                value={newMenuDesc}
                onChange={(e) => setNewMenuDesc(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-surface-container-low text-xs"
              />
            </div>
            <button
              type="submit"
              className="w-full py-3 rounded-full bg-primary text-on-primary text-sm font-semibold"
            >
              Simpan Menu
            </button>
          </form>
        </div>
      )}

      {/* Barista Ticket Print Preview Modal */}
      {ticketOrder && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-primary/45 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-sm bg-surface-container-lowest rounded-3xl p-6 shadow-2xl space-y-4 font-mono text-xs relative">
            <button
              type="button"
              aria-label="Tutup tiket barista"
              onClick={() => setTicketOrder(null)}
              className="absolute top-4 right-4 w-8 h-8 rounded-full bg-surface-container flex items-center justify-center text-on-surface-variant no-print"
            >
              <X className="w-4 h-4" />
            </button>
            <div className="text-center border-b border-dashed border-outline-variant pb-3">
              <p className="font-bold text-sm text-primary">GREEN CAFE BAR</p>
              <p className="text-on-surface-variant mt-0.5">
                {ticketOrder.invoiceNumber}
              </p>
              <p className="text-on-surface-variant">
                {ticketOrder.customerName} ·{' '}
                {ticketOrder.serviceType === 'dine_in'
                  ? ticketOrder.tableNumber
                  : 'TAKE AWAY'}
              </p>
            </div>
            <div className="space-y-2 border-b border-dashed border-outline-variant pb-3">
              {ticketOrder.items.map((item) => (
                <div key={item.id}>
                  <p className="font-bold text-primary">
                    {item.quantity}x {item.name}
                  </p>
                  <p className="text-on-surface-variant pl-4">
                    {item.variantLabel}
                  </p>
                  {item.notes && (
                    <p className="text-secondary pl-4">* {item.notes}</p>
                  )}
                </div>
              ))}
            </div>
            <div className="flex justify-between font-bold text-primary text-sm">
              <span>TOTAL</span>
              <span>{formatRupiah(ticketOrder.totalAmount)}</span>
            </div>
            <button
              type="button"
              onClick={() => window.print()}
              className="w-full py-2.5 rounded-full bg-primary text-on-primary font-sans font-semibold text-xs no-print"
            >
              Cetak Tiket
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
