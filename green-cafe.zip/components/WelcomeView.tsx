'use client';

import React, { useEffect } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { motion } from 'motion/react';
import { ArrowRight, Coffee, Sprout, UtensilsCrossed } from 'lucide-react';
import { useCart } from './CartContext';

export function WelcomeView() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { setServiceMode } = useCart();

  useEffect(() => {
    if (searchParams.get('autostart') === '1') {
      setServiceMode('take_away');
      router.replace('/menu');
    }
  }, [searchParams, router, setServiceMode]);

  const handleSelectDineIn = () => {
    setServiceMode('dine_in');
  };

  const handleSelectTakeAway = () => {
    setServiceMode('take_away');
  };

  return (
    <div className="min-h-screen flex flex-col bg-background text-on-surface relative overflow-hidden">
      {/* Subtle Botanical Ambient Blurs */}
      <div
        aria-hidden="true"
        className="pointer-events-none fixed -top-24 -left-24 w-96 h-96 rounded-full bg-primary/5 blur-3xl"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none fixed -bottom-24 -right-24 w-96 h-96 rounded-full bg-secondary/10 blur-3xl"
      />

      {/* Minimal Top Bar */}
      <header className="fixed top-0 left-0 right-0 z-40 bg-surface/85 backdrop-blur-xl border-b border-surface-container">
        <div className="h-20 max-w-7xl mx-auto px-6 lg:px-12 flex items-center justify-between gap-8">
          <Link
            href="/"
            className="flex items-center gap-2.5 whitespace-nowrap shrink-0"
          >
            <span className="w-9 h-9 rounded-full bg-primary text-surface flex items-center justify-center shadow-sm">
              <Sprout className="w-4 h-4" />
            </span>
            <span className="font-serif text-xl text-primary font-semibold tracking-tight">
              Green Cafe
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-7" aria-label="Navigasi Cepat">
            <Link
              href="/menu"
              onClick={handleSelectTakeAway}
              className="text-sm font-medium text-on-surface-variant hover:text-primary transition-colors whitespace-nowrap shrink-0"
            >
              Daftar Menu
            </Link>
            <Link
              href="/reservasi"
              onClick={handleSelectDineIn}
              className="text-sm font-medium text-on-surface-variant hover:text-primary transition-colors whitespace-nowrap shrink-0"
            >
              Reservasi
            </Link>
            <Link
              href="/pesanan"
              className="text-sm font-medium text-on-surface-variant hover:text-primary transition-colors whitespace-nowrap shrink-0"
            >
              Lacak Pesanan
            </Link>
          </nav>

          <Link
            href="/dashboard"
            className="px-4 py-2 rounded-full bg-surface-container text-primary text-sm font-semibold hover:bg-surface-container-high transition-colors whitespace-nowrap shrink-0"
          >
            Portal Barista
          </Link>
        </div>
      </header>

      {/* Main Hero & Dual Mode Selection */}
      <main className="flex-1 w-full pt-28 pb-16 max-w-7xl mx-auto px-6 lg:px-12 flex flex-col items-center justify-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
          className="text-center flex flex-col items-center max-w-2xl mx-auto mb-12 md:mb-16"
        >
          <h1 className="font-serif text-4xl md:text-5xl text-primary font-semibold tracking-tight mb-4 leading-tight text-balance">
            Selamat Datang di Green Cafe
          </h1>
          <p className="text-base md:text-lg text-on-surface-variant font-normal max-w-md mx-auto leading-relaxed">
            Pilih metode layanan untuk memulai pengalaman kopi Anda.
          </p>
        </motion.div>

        <div className="w-full max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Card 1: Reservasi Dine-In */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, delay: 0.05, ease: [0.16, 1, 0.3, 1] }}
            className="bg-surface-container-lowest rounded-3xl p-8 md:p-10 lg:p-12 border border-outline-variant/40 flex flex-col justify-between transition-all duration-300 hover:shadow-lg"
          >
            <div className="flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-2xl bg-surface-container-low flex items-center justify-center text-primary mb-7">
                <UtensilsCrossed className="w-6 h-6" />
              </div>
              <span className="text-xs font-semibold tracking-widest uppercase text-secondary mb-2">
                Pengalaman Santai
              </span>
              <h2 className="font-serif text-2xl text-primary font-semibold mb-3">
                Reservasi Dine-In
              </h2>
              <p className="text-sm text-on-surface-variant leading-relaxed mb-10">
                Pesan meja lebih dulu untuk menikmati seduhan kopi segar, hidangan khas, dan suasana teduh alami langsung di tempat.
              </p>
            </div>
            <div>
              <Link
                href="/reservasi"
                onClick={handleSelectDineIn}
                className="w-full inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-full bg-primary text-on-primary font-medium text-sm tracking-wide hover:bg-primary-container transition-all duration-200 shadow-sm"
              >
                <span>Reservasi Meja</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </motion.div>

          {/* Card 2: Pesan Take Away */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="bg-surface-container-lowest rounded-3xl p-8 md:p-10 lg:p-12 border border-outline-variant/40 flex flex-col justify-between transition-all duration-300 hover:shadow-lg"
          >
            <div className="flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-2xl bg-surface-container-low flex items-center justify-center text-primary mb-7">
                <Coffee className="w-6 h-6" />
              </div>
              <span className="text-xs font-semibold tracking-widest uppercase text-secondary mb-2">
                Cepat &amp; Praktis
              </span>
              <h2 className="font-serif text-2xl text-primary font-semibold mb-3">
                Pesan Take Away
              </h2>
              <p className="text-sm text-on-surface-variant leading-relaxed mb-10">
                Pesan lebih awal dari mana saja dan ambil langsung pesanan Anda di konter barista tanpa perlu mengantre.
              </p>
            </div>
            <div>
              <Link
                href="/menu"
                onClick={handleSelectTakeAway}
                className="w-full inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-full border border-primary text-primary font-medium text-sm tracking-wide hover:bg-primary hover:text-on-primary transition-all duration-200"
              >
                <span>Pesan Sekarang</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </motion.div>
        </div>
      </main>

      <footer className="w-full py-10 mt-auto relative z-10">
        <div className="max-w-7xl mx-auto px-6 text-center text-xs text-on-surface-variant tracking-wide">
          <p>Buka Setiap Hari 08.00 – 22.00 WIB · Jl. Kopi Alami No. 12</p>
        </div>
      </footer>
    </div>
  );
}
